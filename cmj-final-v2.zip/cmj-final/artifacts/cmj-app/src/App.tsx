import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { AppLayout } from "@/components/layout";

import Landing from "@/pages/landing";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Feed from "@/pages/feed";
import Universal from "@/pages/universal";
import Reels from "@/pages/reels";
import Marketplace from "@/pages/marketplace";
import Chat from "@/pages/chat";
import DM from "@/pages/dm";
import Profile from "@/pages/profile";
import WalletPage from "@/pages/wallet";
import Notifications from "@/pages/notifications";
import Admin from "@/pages/admin";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  
  if (isLoading) return <div className="h-screen w-full flex items-center justify-center bg-background"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>;
  if (!user) {
    window.location.href = "/login";
    return null;
  }
  
  return <Component />;
}

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        
        {/* Protected Routes */}
        <Route path="/feed"><ProtectedRoute component={Feed} /></Route>
        <Route path="/universal"><ProtectedRoute component={Universal} /></Route>
        <Route path="/reels"><ProtectedRoute component={Reels} /></Route>
        <Route path="/marketplace"><ProtectedRoute component={Marketplace} /></Route>
        <Route path="/chat"><ProtectedRoute component={Chat} /></Route>
        <Route path="/dm/:userId"><ProtectedRoute component={DM} /></Route>
        <Route path="/profile/:userId"><ProtectedRoute component={Profile} /></Route>
        <Route path="/wallet"><ProtectedRoute component={WalletPage} /></Route>
        <Route path="/notifications"><ProtectedRoute component={Notifications} /></Route>
        <Route path="/admin"><ProtectedRoute component={Admin} /></Route>
        
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
