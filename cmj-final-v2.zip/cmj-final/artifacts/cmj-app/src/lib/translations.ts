import { create } from 'zustand';

export const languages = [
  { code: 'pt-BR', name: 'Português', flag: '🇧🇷' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
  { code: 'it', name: 'Italiano', flag: '🇮🇹' },
  { code: 'pt-PT', name: 'Português (PT)', flag: '🇵🇹' },
  { code: 'uk', name: 'Українська', flag: '🇺🇦' },
  { code: 'he', name: 'עבריت', flag: '🇮🇱' },
  { code: 'hi', name: 'हिन्दी', flag: '🇮🇳' },
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷' },
];

export const translations: Record<string, Record<string, string>> = {
  'pt-BR': {
    welcome: 'Conectando o Mundo com Jesus',
    subtitle: 'Um ponto de encontro digital onde crentes de todas as nações se conectam.',
    register_free: 'Cadastrar-se Grátis',
    login: 'Entrar',
  },
  'en': {
    welcome: 'Connecting the World with Jesus',
    subtitle: 'A digital meeting point where believers from all nations connect.',
    register_free: 'Sign Up Free',
    login: 'Login',
  }
};

type LangStore = {
  lang: string;
  setLang: (lang: string) => void;
  t: (key: string) => string;
};

export const useLang = create<LangStore>((set, get) => ({
  lang: localStorage.getItem('cmj_lang') || 'pt-BR',
  setLang: (lang) => {
    localStorage.setItem('cmj_lang', lang);
    set({ lang });
  },
  t: (key) => {
    const { lang } = get();
    return translations[lang]?.[key] || translations['en']?.[key] || key;
  }
}));
