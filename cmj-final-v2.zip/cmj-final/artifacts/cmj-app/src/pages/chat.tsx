import { useState, useRef, useEffect } from "react";
import { useListUniversalMessages, useSendUniversalMessage, getListUniversalMessagesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, MessageCircle, Sparkles, Gift } from "lucide-react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000/api";

const GIFT_OPTIONS = [
  { emoji: "🕊️", tipo: "pomba", valor: 200 },
  { emoji: "📖", tipo: "biblia", valor: 500 },
  { emoji: "👑", tipo: "coroa", valor: 1000 },
  { emoji: "🙏", tipo: "maos", valor: 300 },
  { emoji: "🫀", tipo: "coracao", valor: 100 },
];

const COUNTRY_FLAGS: Record<string, string> = {
  "pt-BR": "🇧🇷", "pt-PT": "🇵🇹", "en": "🇺🇸", "es": "🇪🇸",
  "zh": "🇨🇳", "ar": "🇸🇦", "it": "🇮🇹", "uk": "🇺🇦",
  "he": "🇮🇱", "hi": "🇮🇳", "tr": "🇹🇷",
};

export default function Chat() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [showGift, setShowGift] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data: messages, isLoading } = useListUniversalMessages({ limit: 50 });
  const sendMessage = useSendUniversalMessage({
    mutation: {
      onSuccess: () => {
        setMessage("");
        queryClient.invalidateQueries({ queryKey: getListUniversalMessagesQueryKey({ limit: 50 }) });
        setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }), 100);
      },
    },
  });

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    sendMessage.mutate({ data: { conteudo: message } });
  };

  const sendGift = async (tipo: string, emoji: string, valor: number) => {
    const token = localStorage.getItem("cmj_token");
    await fetch(`${API_BASE}/gifts`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ tipo, contexto: "live", destinatario_id: 1 }),
    });
    toast({ title: `${emoji} Presente enviado no Chat Universal! (+${valor} moedas)` });
    setShowGift(false);
    sendMessage.mutate({ data: { conteudo: `Enviou um presente ${emoji} para a comunidade!` } });
  };

  return (
    <div className="flex flex-col h-[100dvh] md:h-[calc(100vh-4rem)] w-full max-w-3xl mx-auto bg-background/50 relative">
      {/* Header */}
      <div className="p-4 border-b bg-card/80 backdrop-blur sticky top-0 z-10 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <MessageCircle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-lg font-serif text-primary">Chat Universal</h2>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-green-500 inline-block"></span>
              24.530 online · 11 idiomas · tradução IA
            </p>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setShowGift(!showGift)} className="gap-1 text-accent">
          <Gift className="w-4 h-4" /> Presentear
        </Button>
      </div>

      {/* Gift bar */}
      <AnimatePresence>
        {showGift && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="border-b bg-card/60 backdrop-blur overflow-hidden">
            <div className="p-3 flex items-center gap-3">
              <span className="text-xs text-muted-foreground font-medium">Enviar para a comunidade:</span>
              {GIFT_OPTIONS.map((g) => (
                <button key={g.tipo} onClick={() => sendGift(g.tipo, g.emoji, g.valor)}
                  className="flex flex-col items-center gap-1 p-2 rounded-xl hover:bg-accent/10 border border-transparent hover:border-accent/30 transition-all">
                  <span className="text-2xl">{g.emoji}</span>
                  <span className="text-[9px] text-muted-foreground">{g.valor}🪙</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24 flex flex-col">
        {isLoading ? (
          <div className="text-center text-muted-foreground p-4">Conectando ao chat global...</div>
        ) : (
          [...(messages || [])].map((msg) => (
            <motion.div key={msg.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${msg.prioridade ? "mb-6 mt-2" : ""}`}>
              <Avatar className="w-8 h-8 mt-1 shrink-0">
                <AvatarImage src={msg.usuario.foto_url || ""} />
                <AvatarFallback className="text-xs">{msg.usuario.nome.substring(0, 2)}</AvatarFallback>
              </Avatar>
              <div className="flex-1 max-w-[85%]">
                <div className="flex items-baseline gap-2 mb-1">
                  <Link href={`/profile/${msg.usuario.id}`}>
                    <span className="font-semibold text-sm hover:underline cursor-pointer">{msg.usuario.nome}</span>
                  </Link>
                  <span className="text-xs" title="País">{COUNTRY_FLAGS[msg.idioma_original] || "🌐"}</span>
                  <span className="text-[10px] text-muted-foreground">
                    {new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
                <div className={`
                  p-3 rounded-2xl relative
                  ${msg.prioridade
                    ? "bg-gradient-to-r from-accent/20 to-primary/10 border border-accent/40 shadow-[0_0_15px_rgba(212,175,55,0.2)] text-foreground"
                    : "bg-muted/50 text-foreground"}
                `}>
                  {msg.prioridade && msg.presente_emoji && (
                    <div className="absolute -top-5 -right-2 text-3xl animate-bounce">{msg.presente_emoji}</div>
                  )}
                  {msg.conteudo}
                  {msg.idioma_original !== "pt-BR" && (
                    <div className="mt-1 flex items-center gap-1 text-[10px] text-muted-foreground/70 justify-end">
                      <Sparkles className="w-3 h-3" /> Traduzido do {msg.idioma_original.toUpperCase()}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-card border-t sticky bottom-16 md:bottom-0">
        <form onSubmit={handleSend} className="flex gap-2">
          <Input
            placeholder="Digite sua mensagem para o mundo... 🌍"
            className="flex-1 rounded-full bg-background"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={sendMessage.isPending}
          />
          <Button type="submit" size="icon" className="rounded-full shrink-0" disabled={!message.trim() || sendMessage.isPending}>
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
