import { useState } from "react";
import { useListPosts, useCreatePost, getListPostsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { Heart, MessageCircle, Share2, Gift, ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000/api";

const GIFT_OPTIONS = [
  { emoji: "🕊️", label: "Pomba", valor: 200, tipo: "pomba" },
  { emoji: "📖", label: "Bíblia", valor: 500, tipo: "biblia" },
  { emoji: "👑", label: "Coroa", valor: 1000, tipo: "coroa" },
  { emoji: "🙏", label: "Oração", valor: 300, tipo: "maos" },
  { emoji: "🫀", label: "Coração", valor: 100, tipo: "coracao" },
];

export default function Feed() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();
  const [content, setContent] = useState("");
  const [openGift, setOpenGift] = useState<number | null>(null);
  const [openComments, setOpenComments] = useState<number | null>(null);
  const [comments, setComments] = useState<Record<number, any[]>>({});
  const [commentText, setCommentText] = useState("");
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set());

  const { data: posts, isLoading } = useListPosts({ tipo: "conexoes" });
  const createPost = useCreatePost({
    mutation: {
      onSuccess: () => {
        setContent("");
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey({ tipo: "conexoes" }) });
      },
    },
  });

  const handleCreatePost = () => {
    if (!content.trim()) return;
    createPost.mutate({ data: { tipo: "texto", conteudo: content, visibilidade: "conexoes" } });
  };

  const handleLike = async (postId: number) => {
    const token = localStorage.getItem("cmj_token");
    await fetch(`${API_BASE}/posts/${postId}/like`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
    });
    setLikedPosts((prev) => {
      const next = new Set(prev);
      next.has(postId) ? next.delete(postId) : next.add(postId);
      return next;
    });
  };

  const loadComments = async (postId: number) => {
    if (openComments === postId) { setOpenComments(null); return; }
    const token = localStorage.getItem("cmj_token");
    const res = await fetch(`${API_BASE}/posts/${postId}/comments`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    setComments((prev) => ({ ...prev, [postId]: data }));
    setOpenComments(postId);
  };

  const sendComment = async (postId: number) => {
    if (!commentText.trim()) return;
    const token = localStorage.getItem("cmj_token");
    await fetch(`${API_BASE}/posts/${postId}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ conteudo: commentText }),
    });
    setCommentText("");
    loadComments(postId);
  };

  const sendGift = async (postId: number, tipo: string, emoji: string, valor: number) => {
    const token = localStorage.getItem("cmj_token");
    await fetch(`${API_BASE}/gifts`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ tipo, contexto: "comentario", destinatario_id: postId }),
    });
    toast({ title: `${emoji} Presente enviado! (+${valor} moedas)` });
    setOpenGift(null);
  };

  return (
    <div className="max-w-2xl mx-auto w-full p-4 space-y-6">
      {/* Create Post */}
      <Card className="p-4 bg-card border-border/50 shadow-sm">
        <div className="flex gap-4">
          <Avatar>
            <AvatarImage src={user?.foto_url || ""} />
            <AvatarFallback>{user?.nome?.substring(0, 2) || "U"}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-3">
            <Textarea
              placeholder="O que o Senhor tem falado ao seu coração?"
              className="resize-none bg-background/50 border-none focus-visible:ring-1 text-base"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
            <div className="flex justify-between items-center">
              <div className="flex gap-2" />
              <Button
                onClick={handleCreatePost}
                disabled={!content.trim() || createPost.isPending}
                className="rounded-full px-6"
              >
                Compartilhar
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Feed List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="animate-pulse flex flex-col gap-4">
            {[1, 2, 3].map((i) => <Card key={i} className="h-40 bg-muted/50" />)}
          </div>
        ) : (
          posts?.map((post) => (
            <motion.div key={post.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="p-4">
                <div className="flex items-center gap-3 mb-4">
                  <Avatar>
                    <AvatarImage src={post.usuario.foto_url || ""} />
                    <AvatarFallback>{post.usuario.nome.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-semibold">
                      {post.usuario.nome}{" "}
                      {post.usuario.selo_autenticidade && <span className="text-accent text-xs">✝️</span>}
                    </h4>
                    <span className="text-xs text-muted-foreground">
                      {new Date(post.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <p className="text-foreground whitespace-pre-wrap">{post.conteudo}</p>

                <div className="flex items-center gap-4 mt-4 pt-4 border-t">
                  <Button
                    variant="ghost" size="sm"
                    className={`gap-2 ${likedPosts.has(post.id) || post.liked ? "text-red-500" : "text-muted-foreground"}`}
                    onClick={() => handleLike(post.id)}
                  >
                    <Heart className={`w-5 h-5 ${likedPosts.has(post.id) || post.liked ? "fill-current" : ""}`} />
                    {post.curtidas > 0 && (post.curtidas > 999 ? (post.curtidas / 1000).toFixed(1) + "k" : post.curtidas)}
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground" onClick={() => loadComments(post.id)}>
                    <MessageCircle className="w-5 h-5" />
                    {post.comentarios_count > 0 && post.comentarios_count}
                    {openComments === post.id ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </Button>
                  <Button variant="ghost" size="sm" className={`gap-2 ${openGift === post.id ? "text-accent" : "text-muted-foreground"}`}
                    onClick={() => setOpenGift(openGift === post.id ? null : post.id)}>
                    <Gift className="w-5 h-5" /> Presentear
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground ml-auto">
                    <Share2 className="w-5 h-5" />
                  </Button>
                </div>

                {/* Gift panel */}
                <AnimatePresence>
                  {openGift === post.id && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                      className="mt-3 pt-3 border-t">
                      <p className="text-xs text-muted-foreground mb-2">Escolha um presente:</p>
                      <div className="flex gap-2 flex-wrap">
                        {GIFT_OPTIONS.map((g) => (
                          <button key={g.tipo} onClick={() => sendGift(post.id, g.tipo, g.emoji, g.valor)}
                            className="flex flex-col items-center gap-1 p-2 rounded-xl bg-muted/50 hover:bg-accent/10 border border-transparent hover:border-accent/30 transition-all">
                            <span className="text-2xl">{g.emoji}</span>
                            <span className="text-[10px]">{g.valor}🪙</span>
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Comments */}
                <AnimatePresence>
                  {openComments === post.id && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                      className="mt-3 pt-3 border-t space-y-3">
                      {(comments[post.id] || []).map((c) => (
                        <div key={c.id} className={`flex gap-2 ${c.presente_emoji ? "bg-accent/10 border border-accent/20 rounded-xl p-2" : ""}`}>
                          <Avatar className="w-7 h-7">
                            <AvatarImage src={c.usuario.foto_url || ""} />
                            <AvatarFallback className="text-xs">{c.usuario.nome.substring(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <span className="text-xs font-semibold">{c.usuario.nome}</span>
                            {c.presente_emoji && <span className="ml-1 text-lg">{c.presente_emoji}</span>}
                            <p className="text-sm">{c.conteudo}</p>
                          </div>
                        </div>
                      ))}
                      <div className="flex gap-2 mt-2">
                        <input className="flex-1 bg-muted/50 rounded-full px-4 py-2 text-sm outline-none border border-border/40"
                          placeholder="Escreva um comentário..." value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && sendComment(post.id)} />
                        <Button size="sm" className="rounded-full px-4" onClick={() => sendComment(post.id)} disabled={!commentText.trim()}>
                          Enviar
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
