import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useRegister } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { languages } from "@/lib/translations";

export default function Register() {
  const [, setLocation] = useLocation();
  const { login: setAuthContext } = useAuth();
  const { toast } = useToast();
  
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [tipoUsuario, setTipoUsuario] = useState<"comum" | "igreja">("comum");
  const [idioma, setIdioma] = useState("pt-BR");

  const registerMutation = useRegister({
    mutation: {
      onSuccess: (data) => {
        setAuthContext(data.token);
        toast({ title: "Conta criada com sucesso!" });
        setLocation("/feed");
      },
      onError: () => {
        toast({
          title: "Erro ao criar conta",
          description: "Verifique os dados e tente novamente.",
          variant: "destructive"
        });
      }
    }
  });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    registerMutation.mutate({ 
      data: { nome, email, senha, tipo_usuario: tipoUsuario, idioma } 
    });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-serif font-bold text-primary">
          Criar sua conta
        </h2>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-card py-8 px-4 shadow sm:rounded-2xl sm:px-10 border border-border/50">
          <form className="space-y-6" onSubmit={onSubmit}>
            <div>
              <Label htmlFor="nome">Nome / Ministério</Label>
              <div className="mt-1">
                <Input
                  id="nome"
                  required
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <div className="mt-1">
                <Input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="password">Senha</Label>
              <div className="mt-1">
                <Input
                  id="password"
                  type="password"
                  required
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label>Tipo de Conta</Label>
              <div className="mt-1">
                <Select value={tipoUsuario} onValueChange={(v: "comum"|"igreja") => setTipoUsuario(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="comum">Usuário Comum</SelectItem>
                    <SelectItem value="igreja">Igreja / Ministério</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Idioma</Label>
              <div className="mt-1">
                <Select value={idioma} onValueChange={setIdioma}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((l) => (
                      <SelectItem key={l.code} value={l.code}>
                        {l.flag} {l.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Button 
                type="submit" 
                className="w-full h-12 text-lg" 
                disabled={registerMutation.isPending}
              >
                {registerMutation.isPending ? "Criando..." : "Criar Conta"}
              </Button>
            </div>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="bg-card px-2 text-muted-foreground">
                  Já tem uma conta?
                </span>
              </div>
            </div>

            <div className="mt-6">
              <Link href="/login">
                <Button variant="outline" className="w-full">
                  Entrar
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
