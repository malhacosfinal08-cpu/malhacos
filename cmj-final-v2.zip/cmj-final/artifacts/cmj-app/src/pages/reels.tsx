import { useState } from "react";
import { useListReels, useLikeReel, getListReelsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2, Music } from "lucide-react";

export default function Reels() {
  const queryClient = useQueryClient();
  const { data: reels, isLoading } = useListReels();
  
  const likeReel = useLikeReel({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListReelsQueryKey() });
      }
    }
  });

  return (
    <div className="h-[100dvh] md:h-[calc(100vh-4rem)] w-full max-w-md mx-auto bg-black relative snap-y snap-mandatory overflow-y-scroll no-scrollbar">
      {isLoading ? (
        <div className="h-full flex items-center justify-center">
          <div className="animate-pulse w-16 h-16 rounded-full bg-white/20"></div>
        </div>
      ) : (
        reels?.map((reel) => (
          <div key={reel.id} className="h-full w-full relative snap-start bg-zinc-900">
            {/* Embed */}
            <div className="absolute inset-0 flex items-center justify-center">
              <iframe 
                src={`${reel.embed_url}?autoplay=1&mute=1&loop=1&controls=0`} 
                className="w-full h-full object-cover pointer-events-none"
                allow="autoplay; encrypted-media"
                allowFullScreen
              />
            </div>
            
            {/* Overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/80 pointer-events-none" />
            
            {/* Right Actions */}
            <div className="absolute right-4 bottom-24 flex flex-col gap-6 items-center z-10">
              <button 
                className="flex flex-col items-center gap-1 text-white"
                onClick={() => likeReel.mutate({ id: reel.id })}
                disabled={likeReel.isPending}
              >
                <div className={`p-3 rounded-full bg-black/40 backdrop-blur-sm transition-colors ${reel.liked ? 'text-red-500' : ''}`}>
                  <Heart className={`w-7 h-7 ${reel.liked ? 'fill-current' : ''}`} />
                </div>
                <span className="text-xs font-medium drop-shadow-md">
                  {reel.curtidas > 999 ? (reel.curtidas/1000).toFixed(1)+'k' : reel.curtidas}
                </span>
              </button>
              
              <button className="flex flex-col items-center gap-1 text-white">
                <div className="p-3 rounded-full bg-black/40 backdrop-blur-sm">
                  <MessageCircle className="w-7 h-7" />
                </div>
                <span className="text-xs font-medium drop-shadow-md">1.2k</span>
              </button>
              
              <button className="flex flex-col items-center gap-1 text-white">
                <div className="p-3 rounded-full bg-black/40 backdrop-blur-sm">
                  <Share2 className="w-7 h-7" />
                </div>
                <span className="text-xs font-medium drop-shadow-md">Compartilhar</span>
              </button>
            </div>
            
            {/* Bottom Info */}
            <div className="absolute bottom-16 left-4 right-20 text-white z-10">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-10 h-10 rounded-full bg-white/20 overflow-hidden border border-white/40">
                  {reel.usuario.foto_url && <img src={reel.usuario.foto_url} className="w-full h-full object-cover" alt="" />}
                </div>
                <div>
                  <h3 className="font-bold text-sm drop-shadow-md">{reel.usuario.nome}</h3>
                </div>
                <Button variant="outline" size="sm" className="h-7 text-xs bg-transparent border-white/40 text-white hover:bg-white/20 ml-2">
                  Seguir
                </Button>
              </div>
              <p className="text-sm font-medium drop-shadow-md line-clamp-2">{reel.titulo}</p>
              <div className="flex items-center gap-2 mt-2 text-xs text-white/80 font-medium drop-shadow-md">
                <Music className="w-3 h-3" />
                Som original - CMJ Global
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
