import { useListNotifications } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Bell, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function Notifications() {
  const { data: notifications, isLoading } = useListNotifications();

  return (
    <div className="max-w-2xl mx-auto w-full p-4 space-y-4 pb-20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-primary flex items-center gap-2">
          <Bell className="w-6 h-6 text-accent" /> Notificações
        </h2>
      </div>

      <div className="space-y-2">
        {isLoading ? (
          [1, 2, 3].map(i => <Card key={i} className="h-24 bg-muted/50 animate-pulse" />)
        ) : notifications?.length ? (
          notifications.map(notif => (
            <motion.div key={notif.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}>
              <Card className={`p-4 flex gap-4 ${!notif.lida ? 'bg-primary/5 border-primary/20' : ''}`}>
                <div className={`mt-1 ${!notif.lida ? 'text-primary' : 'text-muted-foreground'}`}>
                  {notif.tipo === 'success' ? <CheckCircle className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
                </div>
                <div>
                  <h4 className="font-semibold text-sm">{notif.titulo}</h4>
                  <p className="text-sm text-muted-foreground">{notif.mensagem}</p>
                  <span className="text-xs text-muted-foreground/70 mt-1 block">
                    {new Date(notif.created_at).toLocaleString()}
                  </span>
                </div>
              </Card>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <Bell className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p>Você não tem novas notificações.</p>
          </div>
        )}
      </div>
    </div>
  );
}
