import { useState } from "react";
import { useListMarketplaceItems } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Store, MessageCircle, Search, Plus } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

const categorias = ["Todos", "Bíblias", "Literatura", "Moda Modesta", "Instrumentos", "Serviços", "Ministério"];

export default function Marketplace() {
  const { toast } = useToast();
  const { data: items, isLoading } = useListMarketplaceItems();
  const [catAtiva, setCatAtiva] = useState("Todos");
  const [busca, setBusca] = useState("");

  const filtrados = items?.filter((item: any) => {
    const matchCat = catAtiva === "Todos" || item.categoria === catAtiva;
    const matchBusca = !busca || item.titulo.toLowerCase().includes(busca.toLowerCase());
    return matchCat && matchBusca;
  });

  const handleContact = (nome: string) => {
    toast({ title: `Mensagem enviada para ${nome}!`, description: "Aguarde a resposta no seu DM." });
  };

  return (
    <div className="max-w-4xl mx-auto w-full p-4 space-y-6 pb-20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-primary flex items-center gap-2">
          <Store className="w-6 h-6 text-accent" /> Marketplace Gospel
        </h2>
        <Button className="gap-2 rounded-full">
          <Plus className="w-4 h-4" /> Anunciar
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Buscar produtos cristãos..." className="pl-9 rounded-full" value={busca} onChange={(e) => setBusca(e.target.value)} />
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {categorias.map((cat) => (
          <Button key={cat} variant={cat === catAtiva ? "default" : "outline"} className="rounded-full whitespace-nowrap"
            onClick={() => setCatAtiva(cat)}>
            {cat}
          </Button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {isLoading ? (
          [1, 2, 3, 4, 5, 6].map((i) => <Card key={i} className="h-64 bg-muted/50 animate-pulse" />)
        ) : filtrados?.length === 0 ? (
          <div className="col-span-full text-center py-12 text-muted-foreground">
            <Store className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p>Nenhum produto encontrado.</p>
          </div>
        ) : (
          filtrados?.map((item) => (
            <motion.div key={item.id} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
              <Card className="overflow-hidden border-border/50 h-full flex flex-col hover:shadow-md transition-all">
                <div className="aspect-square bg-muted relative overflow-hidden">
                  {item.foto_url ? (
                    <img src={item.foto_url} alt={item.titulo} className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                      <Store className="w-8 h-8 opacity-20" />
                    </div>
                  )}
                  <div className="absolute top-2 right-2 bg-background/90 backdrop-blur text-xs px-2 py-1 rounded-full font-medium shadow-sm">
                    {item.categoria}
                  </div>
                  {item.condicao === "novo" && (
                    <Badge className="absolute top-2 left-2 text-xs bg-green-500/90 hover:bg-green-500">Novo</Badge>
                  )}
                </div>
                <div className="p-3 flex-1 flex flex-col">
                  <h3 className="font-semibold text-sm line-clamp-2 mb-1">{item.titulo}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{item.descricao}</p>
                  <p className="text-accent font-bold text-lg mb-2 mt-auto">R$ {item.preco.toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground mb-2">por {item.usuario.nome}</p>
                  <Button variant="outline" size="sm" className="w-full gap-2" onClick={() => handleContact(item.usuario.nome)}>
                    <MessageCircle className="w-4 h-4" /> Contatar
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
