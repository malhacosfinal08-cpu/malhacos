import { useState } from "react";
import { useRoute } from "wouter";
import { useGetUser, useListPosts, getGetUserQueryKey, getListPostsQueryKey } from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Gift, UserPlus, Users, Heart, MessageCircle, Share2, UserCheck, Church } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000/api";

const GIFT_OPTIONS = [
  { emoji: "🕊️", label: "Pomba da Paz", valor: 200, tipo: "pomba" },
  { emoji: "📖", label: "Bíblia", valor: 500, tipo: "biblia" },
  { emoji: "👑", label: "Coroa da Vitória", valor: 1000, tipo: "coroa" },
  { emoji: "🙏", label: "Mãos em Oração", valor: 300, tipo: "maos" },
  { emoji: "🫀", label: "Coração Reluzente", valor: 100, tipo: "coracao" },
];

const FAMILY_ROLES = ["Pai","Mãe","Filho","Filha","Irmão","Irmã","Tio","Tia","Avô","Avó","Primo","Prima","Cônjuge"];

export default function Profile() {
  const [, params] = useRoute("/profile/:userId");
  const userId = params?.userId ? parseInt(params.userId, 10) : 0;
  const { toast } = useToast();
  const [showGifts, setShowGifts] = useState(false);
  const [showFamily, setShowFamily] = useState(false);
  const [selectedRole, setSelectedRole] = useState("");

  const { data: user, isLoading } = useGetUser(userId, {
    query: { enabled: !!userId, queryKey: getGetUserQueryKey(userId) },
  });
  const { data: posts } = useListPosts({ grupo_id: userId }, {
    query: { enabled: !!userId, queryKey: getListPostsQueryKey({ grupo_id: userId }) },
  });

  const apiAction = async (path: string, body?: any) => {
    const token = localStorage.getItem("cmj_token");
    await fetch(`${API_BASE}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: body ? JSON.stringify(body) : undefined,
    });
  };

  const handleFollow = async () => {
    await apiAction(`/users/${userId}/follow`);
    toast({ title: `Você agora segue ${user?.nome}!` });
  };

  const handleAddFriend = async () => {
    await apiAction(`/users/${userId}/add-friend`);
    toast({ title: `Solicitação enviada para ${user?.nome}!` });
    setShowFamily(true);
  };

  const handleJoinChurch = async () => {
    await apiAction(`/users/${userId}/join-church`);
    toast({ title: `Você se tornou membro de ${user?.nome}! 🙏` });
  };

  const handleGift = async (tipo: string, emoji: string, valor: number) => {
    await apiAction("/gifts", { tipo, contexto: "perfil", destinatario_id: userId });
    toast({ title: `${emoji} Presente enviado para ${user?.nome}! (+${valor} moedas)` });
    setShowGifts(false);
  };

  const handleFamily = async () => {
    if (!selectedRole) return;
    toast({ title: `Laço familiar definido: ${selectedRole} de ${user?.nome} ✝️` });
    setShowFamily(false);
  };

  if (isLoading) return <div className="p-8 text-center animate-pulse">Carregando perfil...</div>;
  if (!user) return <div className="p-8 text-center">Usuário não encontrado.</div>;

  const countryFlag = user.idioma === "pt-BR" ? "🇧🇷" : user.idioma === "en" ? "🇺🇸" : user.idioma === "he" ? "🇮🇱" : user.idioma === "uk" ? "🇺🇦" : user.idioma === "zh" ? "🇨🇳" : user.idioma === "ar" ? "🇸🇦" : user.idioma === "hi" ? "🇮🇳" : "🌐";

  return (
    <div className="w-full pb-20">
      {/* Cover */}
      <div className="h-48 md:h-64 w-full bg-primary/20 relative">
        {user.capa_url ? (
          <img src={user.capa_url} className="w-full h-full object-cover" alt="" />
        ) : (
          <div className="w-full h-full bg-gradient-to-r from-primary to-accent/30" />
        )}
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative -mt-16 sm:-mt-24">
        {/* Avatar & Header */}
        <div className="flex flex-col sm:flex-row sm:items-end gap-4 sm:gap-6 mb-6">
          <div className="relative">
            <Avatar className="w-32 h-32 sm:w-40 sm:h-40 border-4 border-background ring-4 ring-primary/5">
              <AvatarImage src={user.foto_url || ""} />
              <AvatarFallback className="text-4xl">{user.nome.substring(0, 2)}</AvatarFallback>
            </Avatar>
            {user.selo_autenticidade && (
              <div className="absolute -bottom-2 -right-2 bg-accent text-accent-foreground text-xs font-bold px-2 py-1 rounded-full shadow-md">
                ✝️ Verificado
              </div>
            )}
          </div>

          <div className="flex-1 space-y-1 mt-4 sm:mt-0 pb-2">
            <h1 className="text-2xl sm:text-3xl font-bold font-serif flex items-center gap-2 text-foreground">
              {user.nome}
            </h1>
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <span title="País">{countryFlag}</span>
              <span>Membro desde {new Date(user.created_at).getFullYear()}</span>
              {user.tipo_usuario === "igreja" && <Badge variant="secondary">Igreja</Badge>}
            </div>
            {user.igrejas_count > 0 && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Church className="w-3 h-3" /> Membro de {user.igrejas_count} {user.igrejas_count === 1 ? "igreja" : "igrejas"}
              </p>
            )}
          </div>

          <div className="flex flex-wrap gap-2 pb-2">
            {user.tipo_usuario === "igreja" ? (
              <Button className="gap-2" onClick={handleJoinChurch}>
                <Users className="w-4 h-4" /> Tornar-se Membro
              </Button>
            ) : (
              <Button className="gap-2" onClick={handleAddFriend}>
                <UserPlus className="w-4 h-4" /> Adicionar Amigo
              </Button>
            )}
            <Button variant="outline" onClick={handleFollow}>
              <UserCheck className="w-4 h-4 mr-2" /> Seguir
            </Button>
            <Button variant="secondary" className="gap-2" onClick={() => setShowGifts(!showGifts)}>
              <Gift className="w-4 h-4" /> Presentear
            </Button>
          </div>
        </div>

        {/* Gift panel */}
        {showGifts && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4 p-4 bg-card border rounded-xl shadow-sm">
            <p className="font-semibold text-sm mb-3">Escolha um presente para {user.nome}:</p>
            <div className="grid grid-cols-5 gap-2">
              {GIFT_OPTIONS.map((g) => (
                <button key={g.tipo} onClick={() => handleGift(g.tipo, g.emoji, g.valor)}
                  className="flex flex-col items-center gap-1 p-3 rounded-xl bg-muted/50 hover:bg-accent/10 hover:border-accent/40 border border-transparent transition-all">
                  <span className="text-3xl">{g.emoji}</span>
                  <span className="text-[10px] font-medium">{g.label}</span>
                  <span className="text-[10px] text-muted-foreground">{g.valor} 🪙</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Family role panel */}
        {showFamily && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4 p-4 bg-card border border-accent/20 rounded-xl shadow-sm">
            <p className="font-semibold text-sm mb-3">Definir laço familiar com {user.nome}:</p>
            <div className="flex flex-wrap gap-2 mb-3">
              {FAMILY_ROLES.map((r) => (
                <button key={r} onClick={() => setSelectedRole(r)}
                  className={`px-3 py-1 rounded-full text-sm border transition-all ${selectedRole === r ? "bg-primary text-primary-foreground" : "bg-muted/50 hover:bg-muted"}`}>
                  {r}
                </button>
              ))}
            </div>
            <Button size="sm" onClick={handleFamily} disabled={!selectedRole}>Confirmar Parentesco ✝️</Button>
          </motion.div>
        )}

        {/* Bio */}
        {user.bio && (
          <div className="mb-6 max-w-2xl">
            <p className="text-foreground/90 whitespace-pre-wrap">{user.bio}</p>
          </div>
        )}

        {/* Stats */}
        <div className="flex flex-wrap gap-6 mb-8 py-4 border-y border-border/50">
          <div className="text-center">
            <div className="text-xl font-bold">{user.amigos_count}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">Amigos</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold">{user.seguidores_count}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">Seguidores</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold">{user.igrejas_count}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">Igrejas</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold">{user.posts_count}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">Posts</div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="tudo">
          <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent gap-6">
            <TabsTrigger value="tudo" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Tudo</TabsTrigger>
            <TabsTrigger value="familia" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Família ✝️</TabsTrigger>
            <TabsTrigger value="amigos" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Amigos</TabsTrigger>
            <TabsTrigger value="igrejas" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Igrejas</TabsTrigger>
          </TabsList>

          <TabsContent value="tudo" className="mt-6 space-y-4">
            {posts?.length ? posts.map(post => (
              <Card key={post.id} className="p-4">
                <p className="whitespace-pre-wrap">{post.conteudo}</p>
                <div className="flex items-center gap-4 mt-3 pt-3 border-t border-border/30">
                  <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground hover:text-red-500">
                    <Heart className="w-4 h-4" /> {post.curtidas}
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground">
                    <MessageCircle className="w-4 h-4" /> {post.comentarios_count}
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground ml-auto">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            )) : (
              <div className="text-center py-12 text-muted-foreground bg-muted/20 rounded-xl border border-dashed">
                <p>Nenhum post publicado ainda.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="familia" className="mt-6">
            <div className="text-center py-12 text-muted-foreground bg-muted/20 rounded-xl border border-dashed">
              <p className="text-4xl mb-3">✝️</p>
              <p className="font-semibold">Árvore Familiar</p>
              <p className="text-sm mt-1">Adicione como amigo e defina o laço familiar para ver aqui.</p>
            </div>
          </TabsContent>

          <TabsContent value="amigos" className="mt-6">
            <div className="text-center py-12 text-muted-foreground bg-muted/20 rounded-xl border border-dashed">
              <p className="text-4xl mb-3">👥</p>
              <p className="font-semibold">{user.amigos_count} amigos</p>
            </div>
          </TabsContent>

          <TabsContent value="igrejas" className="mt-6">
            <div className="text-center py-12 text-muted-foreground bg-muted/20 rounded-xl border border-dashed">
              <p className="text-4xl mb-3">⛪</p>
              <p className="font-semibold">Membro de {user.igrejas_count} {user.igrejas_count === 1 ? "igreja" : "igrejas"}</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
