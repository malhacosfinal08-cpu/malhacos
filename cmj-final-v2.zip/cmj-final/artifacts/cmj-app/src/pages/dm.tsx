import { useState } from "react";
import { useRoute, Link } from "wouter";
import {
  useListPrivateMessages,
  useSendPrivateMessage,
  useGetUser
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, ArrowLeft, Sparkles, Gift } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000/api";

const GIFT_OPTIONS = [
  { emoji: "🕊️", tipo: "pomba", valor: 200 },
  { emoji: "📖", tipo: "biblia", valor: 500 },
  { emoji: "👑", tipo: "coroa", valor: 1000 },
  { emoji: "🙏", tipo: "maos", valor: 300 },
  { emoji: "🫀", tipo: "coracao", valor: 100 },
];

export default function DM() {
  const [, params] = useRoute("/dm/:userId");
  const userId = params?.userId ? parseInt(params.userId, 10) : 0;
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [showGift, setShowGift] = useState(false);

  const { data: user, isLoading: isUserLoading } = useGetUser(userId, {
    query: { enabled: !!userId, queryKey: [`/api/users/${userId}`] as const },
  });

  const { data: messages, isLoading: isMsgsLoading } = useListPrivateMessages(userId, {
    query: { enabled: !!userId, queryKey: [`/api/users/${userId}`] as const },
  });

  const sendMessage = useSendPrivateMessage({
    mutation: {
      onSuccess: () => {
        setMessage("");
        queryClient.invalidateQueries();
      },
    },
  });

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !userId) return;
    sendMessage.mutate({ userId, data: { conteudo: message } });
  };

  const sendGift = async (tipo: string, emoji: string, valor: number) => {
    const token = localStorage.getItem("cmj_token");
    await fetch(`${API_BASE}/gifts`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ tipo, contexto: "perfil", destinatario_id: userId }),
    });
    toast({ title: `${emoji} Presente enviado para ${user?.nome}! (+${valor} moedas)` });
    setShowGift(false);
  };

  return (
    <div className="flex flex-col h-[100dvh] md:h-[calc(100vh-4rem)] w-full max-w-3xl mx-auto bg-background/50 relative">
      {/* Header */}
      <div className="p-4 border-b bg-card/80 backdrop-blur sticky top-0 z-10 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link href="/chat">
            <Button variant="ghost" size="icon" className="shrink-0 -ml-2">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <Avatar className="w-10 h-10">
            <AvatarImage src={user?.foto_url || ""} />
            <AvatarFallback>{user?.nome?.substring(0, 2)}</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="font-bold text-lg font-serif text-primary">
              {isUserLoading ? "Carregando..." : user?.nome}
              {user?.selo_autenticidade && <span className="text-accent text-xs ml-1">✝️</span>}
            </h2>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-green-500 inline-block"></span> Online
            </p>
          </div>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setShowGift(!showGift)} className="gap-1 text-accent">
          <Gift className="w-4 h-4" /> Presentear
        </Button>
      </div>

      {/* Gift bar */}
      {showGift && (
        <div className="border-b bg-card/60 p-3 flex items-center gap-3">
          <span className="text-xs text-muted-foreground">Enviar presente:</span>
          {GIFT_OPTIONS.map((g) => (
            <button key={g.tipo} onClick={() => sendGift(g.tipo, g.emoji, g.valor)}
              className="flex flex-col items-center gap-1 p-2 rounded-xl hover:bg-accent/10 border border-transparent hover:border-accent/30 transition-all">
              <span className="text-2xl">{g.emoji}</span>
              <span className="text-[9px] text-muted-foreground">{g.valor}🪙</span>
            </button>
          ))}
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-24 flex flex-col-reverse">
        {isMsgsLoading ? (
          <div className="text-center text-muted-foreground p-4">Carregando mensagens...</div>
        ) : (
          [...(messages || [])].reverse().map((msg: any) => {
            const isMe = msg.usuario.id !== userId;
            return (
              <div key={msg.id} className={`flex gap-3 ${isMe ? "flex-row-reverse" : ""}`}>
                <Avatar className="w-8 h-8 mt-1 shrink-0">
                  <AvatarImage src={msg.usuario.foto_url || ""} />
                  <AvatarFallback>{msg.usuario.nome.substring(0, 2)}</AvatarFallback>
                </Avatar>
                <div className={`flex flex-col max-w-[75%] ${isMe ? "items-end" : "items-start"}`}>
                  <span className="text-[10px] text-muted-foreground mb-1">
                    {new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                  <div className={`p-3 rounded-2xl ${isMe ? "bg-primary text-primary-foreground rounded-tr-none" : "bg-muted/50 text-foreground rounded-tl-none"}`}>
                    {msg.conteudo}
                    {!isMe && msg.idioma_original !== "pt-BR" && (
                      <div className="mt-1 flex items-center gap-1 text-[10px] text-muted-foreground/70">
                        <Sparkles className="w-3 h-3" /> Traduzido do {msg.idioma_original.toUpperCase()}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Input */}
      <div className="p-4 bg-card border-t sticky bottom-16 md:bottom-0">
        <form onSubmit={handleSend} className="flex gap-2">
          <Input
            placeholder="Digite uma mensagem..."
            className="flex-1 rounded-full bg-background"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={sendMessage.isPending}
          />
          <Button type="submit" size="icon" className="rounded-full shrink-0"
            disabled={!message.trim() || sendMessage.isPending}>
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
