import { useState } from "react";
import { useGetAdminStats, useGetMe, getGetAdminStatsQueryKey, getGetMeQueryKey } from "@workspace/api-client-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Users, Coins, Activity, TrendingUp, Bell, Ban, Sliders, Building2, CheckCircle, XCircle, MessageSquare, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000/api";

async function apiPost(path: string, body: any) {
  const token = localStorage.getItem("cmj_token");
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body),
  });
  return res.json();
}
async function apiPatch(path: string, body: any) {
  const token = localStorage.getItem("cmj_token");
  const res = await fetch(`${API_BASE}${path}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(body),
  });
  return res.json();
}
async function apiGet(path: string) {
  const token = localStorage.getItem("cmj_token");
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  return res.json();
}

export default function Admin() {
  const { toast } = useToast();
  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: stats, isLoading } = useGetAdminStats({
    query: { enabled: user?.tipo_usuario === "admin", queryKey: getGetAdminStatsQueryKey() },
  });

  // Harpa Mensageira
  const [harpaTitle, setHarpaTitle] = useState("");
  const [harpaMsg, setHarpaMsg] = useState("");
  const [harpaModo, setHarpaModo] = useState<"global" | "privado">("global");
  const [harpaUserId, setHarpaUserId] = useState("");

  // Engagement
  const [viewsMulti, setViewsMulti] = useState("5");
  const [curtidasMulti, setCurtidasMulti] = useState("3");

  // Banner
  const [bannerTitulo, setBannerTitulo] = useState("");
  const [bannerSubtitulo, setBannerSubtitulo] = useState("");

  // Users list
  const [usersList, setUsersList] = useState<any[]>([]);
  const [usersSearch, setUsersSearch] = useState("");
  const [withdrawalsList, setWithdrawalsList] = useState<any[]>([]);
  const [blacklistList, setBlacklistList] = useState<any[]>([]);

  if (user?.tipo_usuario !== "admin") {
    return (
      <div className="p-8 text-center text-destructive">
        <Ban className="w-16 h-16 mx-auto mb-4 opacity-40" />
        <h2 className="text-xl font-bold">Acesso Negado</h2>
        <p className="text-muted-foreground mt-2">Apenas administradores podem acessar este painel.</p>
      </div>
    );
  }

  const handleHarpa = async () => {
    if (!harpaTitle || !harpaMsg) return;
    const res = await apiPost("/admin/notify", { titulo: harpaTitle, mensagem: harpaMsg, modo: harpaModo, destinatario_id: harpaUserId || undefined });
    toast({ title: res.message || "Notificação enviada!" });
    setHarpaTitle(""); setHarpaMsg("");
  };

  const handleEngagement = async () => {
    const res = await apiPatch("/admin/engagement", { views_multiplier: Number(viewsMulti), curtidas_multiplier: Number(curtidasMulti) });
    toast({ title: `Multiplicadores atualizados: Views x${res.views_multiplier} | Curtidas x${res.curtidas_multiplier}` });
  };

  const handleBanner = async () => {
    if (!bannerTitulo && !bannerSubtitulo) return;
    await apiPatch("/admin/banner", { titulo: bannerTitulo, subtitulo: bannerSubtitulo });
    toast({ title: "Banner atualizado com sucesso!" });
  };

  const loadUsers = async () => {
    const data = await apiGet(`/admin/users${usersSearch ? `?search=${usersSearch}` : ""}`);
    setUsersList(data);
  };

  const banUser = async (id: number, nome: string) => {
    await apiPost(`/users/${id}/ban`, { motivo: "Banido pelo administrador" });
    toast({ title: `${nome} foi banido e adicionado à blacklist.`, variant: "destructive" });
    loadUsers();
  };

  const loadWithdrawals = async () => {
    const data = await apiGet("/admin/withdrawals");
    setWithdrawalsList(data);
  };

  const approveWithdrawal = async (id: number, valor: number) => {
    const res = await apiPost(`/admin/withdrawals/${id}/approve`, {});
    toast({ title: res.message });
    loadWithdrawals();
  };

  const loadBlacklist = async () => {
    const data = await apiGet("/admin/blacklist");
    setBlacklistList(data);
  };

  return (
    <div className="max-w-6xl mx-auto w-full p-4 space-y-6 pb-20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-primary flex items-center gap-2">
          🛡️ Painel Administrativo Master
        </h2>
        <Badge variant="secondary" className="text-xs">Admin</Badge>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Usuários</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats?.total_usuarios || 0}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ativos Hoje</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats?.usuarios_ativos_hoje || 0}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Depositado (Mês)</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold text-green-600">R$ {stats?.total_depositado?.toFixed(2) || "0.00"}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sacado (Mês)</CardTitle>
            <Coins className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold text-red-500">R$ {stats?.total_sacado?.toFixed(2) || "0.00"}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Igrejas</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats?.total_igrejas || 0}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Presentes Enviados</CardTitle>
            <Coins className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats?.total_presentes || 0}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Posts Totais</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats?.total_posts || 0}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ativos Mês</CardTitle>
            <Activity className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent><div className="text-2xl font-bold">{stats?.usuarios_ativos_mes || 0}</div></CardContent>
        </Card>
      </div>

      <Tabs defaultValue="usuarios" className="w-full mt-6">
        <TabsList className="flex flex-wrap h-auto gap-1">
          <TabsTrigger value="usuarios">👥 Usuários</TabsTrigger>
          <TabsTrigger value="financeiro">💰 Financeiro</TabsTrigger>
          <TabsTrigger value="engajamento">📊 Engajamento</TabsTrigger>
          <TabsTrigger value="harpa">🎺 Harpa</TabsTrigger>
          <TabsTrigger value="banner">🖼️ Banner</TabsTrigger>
          <TabsTrigger value="blacklist">🚫 Blacklist</TabsTrigger>
        </TabsList>

        {/* USUÁRIOS */}
        <TabsContent value="usuarios" className="mt-4">
          <Card>
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-lg">Gestão de Usuários</h3>
              <div className="flex gap-2">
                <Input placeholder="Buscar por nome ou e-mail..." value={usersSearch} onChange={(e) => setUsersSearch(e.target.value)} />
                <Button onClick={loadUsers}>Buscar</Button>
              </div>
              {usersList.length > 0 && (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {usersList.map((u) => (
                    <div key={u.id} className="flex items-center justify-between p-3 rounded-lg border bg-muted/20">
                      <div>
                        <p className="font-semibold text-sm">{u.nome} {u.selo_autenticidade && "✝️"}</p>
                        <p className="text-xs text-muted-foreground">{u.email} · {u.tipo_usuario} · 💰 {u.saldo_moedas} moedas</p>
                        <Badge variant={u.status === "ativo" ? "default" : "destructive"} className="text-xs mt-1">{u.status}</Badge>
                      </div>
                      <div className="flex gap-2">
                        {u.status !== "banido" && (
                          <Button size="sm" variant="destructive" onClick={() => banUser(u.id, u.nome)}>
                            <Ban className="w-4 h-4 mr-1" /> Banir
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {usersList.length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-4">Clique em "Buscar" para listar usuários.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* FINANCEIRO */}
        <TabsContent value="financeiro" className="mt-4">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg">Solicitações de Saque</h3>
                <Button onClick={loadWithdrawals} variant="outline" size="sm">Carregar</Button>
              </div>
              {withdrawalsList.length > 0 ? (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {withdrawalsList.map((w) => (
                    <div key={w.id} className="flex items-center justify-between p-3 rounded-lg border">
                      <div>
                        <p className="font-semibold text-sm">{w.usuario.nome}</p>
                        <p className="text-xs text-muted-foreground">R$ {w.valor.toFixed(2)} · PIX: {w.chave_pix}</p>
                        {w.automatico && <Badge className="text-xs mt-1 bg-green-500/20 text-green-700">Saque Automático</Badge>}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={w.status === "pendente" ? "secondary" : w.status === "aprovado" ? "default" : "destructive"}>
                          {w.status}
                        </Badge>
                        {w.status === "pendente" && (
                          <Button size="sm" onClick={() => approveWithdrawal(w.id, w.valor)}>
                            <CheckCircle className="w-4 h-4 mr-1" /> Aprovar
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-sm text-center py-4">Clique em "Carregar" para ver saques pendentes.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ENGAJAMENTO */}
        <TabsContent value="engajamento" className="mt-4">
          <Card>
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Sliders className="w-5 h-5" /> Simulador de Engajamento Internacional</h3>
              <p className="text-sm text-muted-foreground">Ajuste os multiplicadores de visualizações e curtidas para simular movimentação orgânica na fase inicial.</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium block mb-1">Views Multiplicador (atual: x{viewsMulti})</label>
                  <Input type="number" min="1" max="100" value={viewsMulti} onChange={(e) => setViewsMulti(e.target.value)} />
                </div>
                <div>
                  <label className="text-sm font-medium block mb-1">Curtidas Multiplicador (atual: x{curtidasMulti})</label>
                  <Input type="number" min="1" max="100" value={curtidasMulti} onChange={(e) => setCurtidasMulti(e.target.value)} />
                </div>
              </div>
              <Button onClick={handleEngagement} className="w-full">Aplicar Multiplicadores</Button>
              <div className="bg-muted/30 rounded-lg p-4 space-y-2 text-sm">
                <p className="font-semibold">Banco de Comentários Automáticos (simulados em posts):</p>
                {["Amém! Glória a Deus! 🙏","Hallelujah from India! 🇮🇳❤️","ברוך השם! 🇮🇱","God bless you! 🇺🇸✝️","Amínь! 🇺🇦🙏","哈利路亚！🇨🇳","¡Aleluya! 🇪🇸❤️"].map((c, i) => (
                  <p key={i} className="text-muted-foreground">· {c}</p>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* HARPA MENSAGEIRA */}
        <TabsContent value="harpa" className="mt-4">
          <Card>
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Bell className="w-5 h-5 text-accent" /> 🎺 Harpa Mensageira</h3>
              <p className="text-sm text-muted-foreground">Envie notificações em massa para todos os usuários (Global) ou diretamente para uma conta específica (Privado).</p>
              <div className="flex gap-2">
                <Button variant={harpaModo === "global" ? "default" : "outline"} onClick={() => setHarpaModo("global")} className="flex-1">
                  🌍 Global
                </Button>
                <Button variant={harpaModo === "privado" ? "default" : "outline"} onClick={() => setHarpaModo("privado")} className="flex-1">
                  👤 Privado
                </Button>
              </div>
              {harpaModo === "privado" && (
                <Input placeholder="ID do usuário destinatário" value={harpaUserId} onChange={(e) => setHarpaUserId(e.target.value)} />
              )}
              <Input placeholder="Título da notificação" value={harpaTitle} onChange={(e) => setHarpaTitle(e.target.value)} />
              <Input placeholder="Mensagem..." value={harpaMsg} onChange={(e) => setHarpaMsg(e.target.value)} />
              <Button onClick={handleHarpa} className="w-full" disabled={!harpaTitle || !harpaMsg}>
                🎺 Disparar Harpa Mensageira
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* BANNER */}
        <TabsContent value="banner" className="mt-4">
          <Card>
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-lg">🖼️ Banner Dinâmico da Landing Page</h3>
              <p className="text-sm text-muted-foreground">Altere o título e subtítulo do banner principal exibido antes do login.</p>
              <Input placeholder="Novo título do banner" value={bannerTitulo} onChange={(e) => setBannerTitulo(e.target.value)} />
              <Input placeholder="Novo subtítulo do banner" value={bannerSubtitulo} onChange={(e) => setBannerSubtitulo(e.target.value)} />
              <Button onClick={handleBanner} className="w-full" disabled={!bannerTitulo && !bannerSubtitulo}>
                Atualizar Banner
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* BLACKLIST */}
        <TabsContent value="blacklist" className="mt-4">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-lg flex items-center gap-2"><Ban className="w-5 h-5 text-destructive" /> Lista Negra Definitiva</h3>
                <Button onClick={loadBlacklist} variant="outline" size="sm">Carregar</Button>
              </div>
              {blacklistList.length > 0 ? (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {blacklistList.map((b) => (
                    <div key={b.id} className="p-3 rounded-lg border border-destructive/20 bg-destructive/5">
                      <p className="font-semibold text-sm text-destructive">{b.email}</p>
                      {b.cpf && <p className="text-xs text-muted-foreground">CPF: {b.cpf}</p>}
                      {b.telefone && <p className="text-xs text-muted-foreground">Tel: {b.telefone}</p>}
                      <p className="text-xs mt-1">{b.motivo}</p>
                      <p className="text-xs text-muted-foreground">{new Date(b.created_at).toLocaleDateString()}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-sm text-center py-4">Clique em "Carregar" para ver a blacklist.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
