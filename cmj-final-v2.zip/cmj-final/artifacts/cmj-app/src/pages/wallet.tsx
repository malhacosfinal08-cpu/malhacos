import { useState } from "react";
import { useGetMe, useRechargeWallet, useRequestWithdrawal, useListGiftHistory } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Wallet, ArrowUpRight, ArrowDownRight, Coins, History, QrCode } from "lucide-react";

const GIFT_EMOJIS: Record<string, string> = {
  biblia: "📖", pomba: "🕊️", coroa: "👑", maos: "🙏", coracao: "🫀",
};

export default function WalletPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: user } = useGetMe();
  const { data: history } = useListGiftHistory();

  const [rechargeAmount, setRechargeAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [pixKey, setPixKey] = useState("");
  const [showPix, setShowPix] = useState(false);

  const recharge = useRechargeWallet({
    mutation: {
      onSuccess: () => {
        toast({ title: "✅ Recarga efetuada! Moedas adicionadas ao saldo." });
        setRechargeAmount(""); setShowPix(false);
        queryClient.invalidateQueries();
      },
    },
  });

  const withdraw = useRequestWithdrawal({
    mutation: {
      onSuccess: () => {
        toast({ title: "✅ Saque solicitado! Aguarde processamento." });
        setWithdrawAmount(""); setPixKey("");
        queryClient.invalidateQueries();
      },
    },
  });

  const handleRecharge = () => {
    if (!rechargeAmount) return;
    recharge.mutate({ data: { valor_real: Number(rechargeAmount), metodo: "pix" } });
  };

  const handleWithdraw = () => {
    if (!withdrawAmount || !pixKey) return;
    withdraw.mutate({ data: { valor: Number(withdrawAmount), chave_pix: pixKey } });
  };

  const moedas = user?.saldo_moedas || 0;
  const valorReais = (moedas * 1).toFixed(2);

  return (
    <div className="max-w-2xl mx-auto w-full p-4 space-y-6 pb-20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-primary flex items-center gap-2">
          <Wallet className="w-6 h-6 text-accent" /> Minha Carteira
        </h2>
      </div>

      {/* Balance Card */}
      <Card className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground border-none shadow-lg overflow-hidden relative">
        <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
        <CardContent className="p-8 relative">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-primary-foreground/70 font-medium mb-1">Saldo Disponível</p>
              <div className="text-4xl font-bold flex items-center gap-2">
                <Coins className="w-8 h-8 text-accent" />
                {moedas.toLocaleString()}
              </div>
              <p className="text-sm text-primary-foreground/60 mt-2">≈ R$ {valorReais} · 1 Moeda = R$ 1,00</p>
            </div>
            <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-sm">
              <Wallet className="w-8 h-8 text-accent" />
            </div>
          </div>
          <div className="flex gap-4 mt-6 text-xs text-primary-foreground/60">
            <span>💳 Pix · Stripe · PayPal</span>
            <span>·</span>
            <span>🌍 Wise International</span>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="recharge" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="recharge">Recarregar</TabsTrigger>
          <TabsTrigger value="withdraw">Sacar</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
        </TabsList>

        <TabsContent value="recharge" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <ArrowDownRight className="w-5 h-5 text-green-500" /> Adicionar Moedas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Valor (R$)</label>
                <Input type="number" placeholder="100.00" value={rechargeAmount} onChange={(e) => setRechargeAmount(e.target.value)} />
              </div>
              <div className="flex gap-2 flex-wrap">
                {[10, 25, 50, 100, 250, 500].map((v) => (
                  <Button key={v} variant="outline" size="sm" className="rounded-full" onClick={() => setRechargeAmount(String(v))}>
                    R$ {v}
                  </Button>
                ))}
              </div>
              <Button className="w-full gap-2" disabled={recharge.isPending || !rechargeAmount} onClick={() => setShowPix(!showPix)}>
                <QrCode className="w-4 h-4" /> Gerar PIX
              </Button>
              {showPix && rechargeAmount && (
                <div className="bg-muted/30 rounded-xl p-4 text-center space-y-2">
                  <div className="text-6xl">📱</div>
                  <p className="font-semibold">PIX gerado: R$ {Number(rechargeAmount).toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground">Escaneie o QR Code no seu banco para confirmar</p>
                  <Button size="sm" onClick={handleRecharge} disabled={recharge.isPending}>
                    {recharge.isPending ? "Processando..." : "✅ Confirmar Pagamento (Demo)"}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="withdraw" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <ArrowUpRight className="w-5 h-5 text-accent" /> Solicitar Saque
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted/30 rounded-lg p-3 text-sm">
                <p className="font-medium">Taxa de manutenção: 30%</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Você recebe 70% do valor solicitado após aprovação administrativa.
                </p>
                {withdrawAmount && (
                  <p className="text-green-600 font-semibold mt-2">
                    Você receberá: R$ {(Number(withdrawAmount) * 0.7).toFixed(2)}
                  </p>
                )}
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Valor a sacar (em moedas)</label>
                <Input type="number" placeholder="0" value={withdrawAmount} onChange={(e) => setWithdrawAmount(e.target.value)} />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Chave PIX</label>
                <Input placeholder="Email, CPF ou celular" value={pixKey} onChange={(e) => setPixKey(e.target.value)} />
              </div>
              <Button className="w-full" disabled={withdraw.isPending || !withdrawAmount || !pixKey || Number(withdrawAmount) > moedas} onClick={handleWithdraw}>
                {withdraw.isPending ? "Solicitando..." : "Solicitar Retirada"}
              </Button>
              {Number(withdrawAmount) > moedas && (
                <p className="text-destructive text-xs text-center">Saldo insuficiente.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <History className="w-5 h-5" /> Histórico de Presentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {history?.map((gift) => (
                  <div key={gift.id} className="flex justify-between items-center py-3 border-b last:border-0">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{GIFT_EMOJIS[gift.tipo] || "🎁"}</span>
                      <div>
                        <p className="font-medium text-sm">de {gift.remetente.nome}</p>
                        <p className="text-xs text-muted-foreground capitalize">{gift.contexto} · {new Date(gift.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-accent">+{gift.valor_moedas} 🪙</div>
                      <div className="text-xs text-muted-foreground">≈ R$ {gift.valor_liquido?.toFixed(2)}</div>
                    </div>
                  </div>
                ))}
                {!history?.length && (
                  <p className="text-sm text-muted-foreground text-center py-6">Nenhum presente recebido ainda.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
