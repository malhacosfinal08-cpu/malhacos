import { useState } from "react";
import { useListPosts, useLikePost, getListPostsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2, Globe, Sparkles, Gift } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000/api";

const GIFT_OPTIONS = [
  { emoji: "🕊️", tipo: "pomba", valor: 200 },
  { emoji: "📖", tipo: "biblia", valor: 500 },
  { emoji: "👑", tipo: "coroa", valor: 1000 },
  { emoji: "🙏", tipo: "maos", valor: 300 },
  { emoji: "🫀", tipo: "coracao", valor: 100 },
];

const COUNTRY_FLAGS: Record<string, string> = {
  "pt-BR": "🇧🇷", "pt-PT": "🇵🇹", "en": "🇺🇸", "es": "🇪🇸",
  "zh": "🇨🇳", "ar": "🇸🇦", "it": "🇮🇹", "uk": "🇺🇦",
  "he": "🇮🇱", "hi": "🇮🇳", "tr": "🇹🇷",
};

export default function Universal() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: posts, isLoading } = useListPosts({ tipo: "universal" });
  const [openGift, setOpenGift] = useState<number | null>(null);

  const likePost = useLikePost({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListPostsQueryKey({ tipo: "universal" }) });
      },
    },
  });

  const sendGift = async (postId: number, tipo: string, emoji: string, valor: number) => {
    const token = localStorage.getItem("cmj_token");
    await fetch(`${API_BASE}/gifts`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ tipo, contexto: "comentario", destinatario_id: postId }),
    });
    toast({ title: `${emoji} Presente enviado! (+${valor} moedas)` });
    setOpenGift(null);
  };

  return (
    <div className="max-w-2xl mx-auto w-full p-4 space-y-6 pb-20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-serif font-bold text-primary flex items-center gap-2">
          <Globe className="w-6 h-6 text-accent" /> Feed Universal Global
        </h2>
        <div className="flex items-center gap-1 text-xs text-muted-foreground bg-muted/50 px-3 py-1 rounded-full">
          <span className="w-2 h-2 rounded-full bg-green-500 inline-block"></span>
          Ao vivo · 11 países
        </div>
      </div>

      <div className="space-y-4">
        {isLoading ? (
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => <Card key={i} className="h-40 bg-muted/50" />)}
          </div>
        ) : (
          posts?.map((post) => (
            <motion.div key={post.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="p-4 bg-card border-border/50 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-primary/10 text-primary text-xs px-2 py-1 rounded-bl-lg flex items-center gap-1 font-medium">
                  <Sparkles className="w-3 h-3" /> Traduzido por IA
                </div>

                <div className="flex items-center gap-3 mb-4 mt-2">
                  <Link href={`/profile/${post.usuario.id}`}>
                    <Avatar className="cursor-pointer hover:ring-2 ring-primary/30 transition-all">
                      <AvatarImage src={post.usuario.foto_url || ""} />
                      <AvatarFallback>{post.usuario.nome.substring(0, 2)}</AvatarFallback>
                    </Avatar>
                  </Link>
                  <div>
                    <h4 className="font-semibold flex items-center gap-1">
                      <Link href={`/profile/${post.usuario.id}`}>
                        <span className="hover:underline cursor-pointer">{post.usuario.nome}</span>
                      </Link>
                      {post.usuario.selo_autenticidade && <span className="text-accent text-xs">✝️</span>}
                      <span className="text-xs ml-1">{COUNTRY_FLAGS["pt-BR"]}</span>
                    </h4>
                    <span className="text-xs text-muted-foreground">
                      {new Date(post.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <p className="text-foreground whitespace-pre-wrap">{post.conteudo}</p>

                <div className="flex items-center gap-4 mt-4 pt-4 border-t border-border/30">
                  <Button
                    variant="ghost" size="sm"
                    className={`gap-2 ${post.liked ? "text-red-500" : "text-muted-foreground"}`}
                    onClick={() => likePost.mutate({ id: post.id })}
                    disabled={likePost.isPending}
                  >
                    <Heart className={`w-5 h-5 ${post.liked ? "fill-current" : ""}`} />
                    {post.curtidas > 0 && (post.curtidas > 999 ? (post.curtidas / 1000).toFixed(1) + "k" : post.curtidas)}
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground">
                    <MessageCircle className="w-5 h-5" />
                    {post.comentarios_count > 0 && post.comentarios_count}
                  </Button>
                  <Button variant="ghost" size="sm"
                    className={`gap-2 ${openGift === post.id ? "text-accent" : "text-muted-foreground"}`}
                    onClick={() => setOpenGift(openGift === post.id ? null : post.id)}>
                    <Gift className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground ml-auto">
                    <Share2 className="w-5 h-5" />
                  </Button>
                </div>

                <AnimatePresence>
                  {openGift === post.id && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                      className="mt-3 pt-3 border-t">
                      <p className="text-xs text-muted-foreground mb-2">Presentear esta publicação:</p>
                      <div className="flex gap-2">
                        {GIFT_OPTIONS.map((g) => (
                          <button key={g.tipo} onClick={() => sendGift(post.id, g.tipo, g.emoji, g.valor)}
                            className="flex flex-col items-center gap-1 p-2 rounded-xl bg-muted/50 hover:bg-accent/10 border border-transparent hover:border-accent/30 transition-all">
                            <span className="text-2xl">{g.emoji}</span>
                            <span className="text-[9px] text-muted-foreground">{g.valor}🪙</span>
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
