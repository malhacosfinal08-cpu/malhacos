import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useLang, languages } from "@/lib/translations";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Film, Store, Radio, MessageCircle, Globe, Users, Heart, ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";
import { useGetBanner } from "@workspace/api-client-react";

export default function Landing() {
  const { lang, setLang, t } = useLang();
  const { data: banner } = useGetBanner();

  const features = [
    { icon: Film, title: "Reels Gospel", desc: "Testemunhos e pregações em vídeo do mundo todo", color: "bg-blue-500/10 text-blue-600" },
    { icon: Store, title: "Marketplace Cristão", desc: "Bíblias, literatura, instrumentos e serviços", color: "bg-green-500/10 text-green-600" },
    { icon: Radio, title: "Lives Globais", desc: "Cultos e conferências ao vivo via YouTube/Instagram", color: "bg-red-500/10 text-red-600" },
    { icon: MessageCircle, title: "Chat Universal", desc: "Comunidade global com tradução automática por IA", color: "bg-purple-500/10 text-purple-600" },
    { icon: Globe, title: "11 Idiomas", desc: "Interface traduzida: PT, EN, ES, ZH, AR, HE e mais", color: "bg-yellow-500/10 text-yellow-700" },
    { icon: Users, title: "Árvore Familiar", desc: "Conecte pai, mãe, filhos, irmãos e cônjuge na fé", color: "bg-pink-500/10 text-pink-600" },
    { icon: Heart, title: "Presentes Virtuais", desc: "Envie dízimos e presentes em qualquer moeda", color: "bg-orange-500/10 text-orange-600" },
    { icon: ShieldCheck, title: "Contas Verificadas", desc: "Igrejas e ministérios com Selo de Autenticidade ✝️", color: "bg-teal-500/10 text-teal-600" },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background relative overflow-hidden">
      {/* Language selector */}
      <div className="absolute top-0 w-full p-4 flex justify-end z-20">
        <Select value={lang} onValueChange={setLang}>
          <SelectTrigger className="w-[160px] bg-card/80 backdrop-blur-md border-primary/20 text-foreground">
            <SelectValue placeholder="Idioma" />
          </SelectTrigger>
          <SelectContent>
            {languages.map((l) => (
              <SelectItem key={l.code} value={l.code}>
                {l.flag} {l.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center pt-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 bg-accent/10 border border-accent/20 text-accent text-sm font-medium px-4 py-2 rounded-full mb-6">
            🌍 +2 milhões de cristãos em 142 países
          </div>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-primary tracking-tight mb-6 drop-shadow-sm">
            {banner?.titulo || t('welcome')}
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
            {banner?.subtitulo || t('subtitle')}
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/register" className="w-full sm:w-auto">
              <Button size="lg" className="w-full text-lg h-14 px-10 rounded-full shadow-[0_0_20px_rgba(212,175,55,0.3)] border border-accent/20">
                {t('register_free')}
              </Button>
            </Link>
            <Link href="/login" className="w-full sm:w-auto">
              <Button variant="outline" size="lg" className="w-full text-lg h-14 px-10 rounded-full border-primary/20 hover:bg-primary/5">
                {t('login')}
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Demo preview section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="mt-16 w-full max-w-3xl bg-card border border-border/50 rounded-2xl p-6 shadow-sm"
        >
          <h2 className="text-center text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-4">
            🎺 Mensagens ao vivo do Chat Universal
          </h2>
          <div className="space-y-3">
            {[
              { flag: "🇧🇷", nome: "Pastor Marcos", msg: "Glória a Deus! Orando por todos vocês! 🙌", prioridade: false },
              { flag: "🇺🇸", nome: "Sarah Johnson", msg: "God bless you all! United in prayer! ✝️", prioridade: true, emoji: "👑" },
              { flag: "🇮🇱", nome: "Rabbi Cohen", msg: "שלום! Paz de Israel para o mundo! 🕊️", prioridade: false },
              { flag: "🇮🇳", nome: "Rev. Priya Sharma", msg: "Hallelujah from India! Healing for the nations! 🙏", prioridade: true, emoji: "🙏" },
            ].map((m, i) => (
              <div key={i} className={`flex items-center gap-3 p-3 rounded-xl ${m.prioridade ? 'bg-accent/10 border border-accent/30' : 'bg-muted/40'}`}>
                <span className="text-xl">{m.flag}</span>
                <div className="flex-1 min-w-0">
                  <span className="font-semibold text-sm">{m.nome}</span>
                  <p className="text-sm text-muted-foreground truncate">{m.msg}</p>
                </div>
                {m.prioridade && <span className="text-2xl animate-bounce">{(m as any).emoji}</span>}
              </div>
            ))}
          </div>
        </motion.div>

        {/* Features grid */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16 w-full"
        >
          {features.map((card, i) => {
            const Icon = card.icon;
            return (
              <div key={i} className="bg-card border border-border/50 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${card.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-semibold text-lg mb-1">{card.title}</h3>
                <p className="text-muted-foreground text-sm">{card.desc}</p>
              </div>
            );
          })}
        </motion.div>

        {/* CTA bottom */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-20 mb-16 text-center"
        >
          <p className="text-muted-foreground mb-4">Infraestrutura custo zero · Custo R$0 em servidores de vídeo · Open para todas as culturas</p>
          <Link href="/register">
            <Button size="lg" className="rounded-full px-12 h-14 text-lg shadow-lg">
              Entrar na Plataforma Grátis 🕊️
            </Button>
          </Link>
        </motion.div>
      </main>
    </div>
  );
}
