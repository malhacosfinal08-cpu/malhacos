import { Link, useLocation } from "wouter";
import { Home, Globe, Film, Store, MessageCircle, User as UserIcon, Bell, LogOut, Wallet, Shield } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useLang } from "@/lib/translations";
import { cn } from "@/lib/utils";
import { Button } from "./ui/button";

const navItems = [
  { icon: Home, label: "Feed", href: "/feed" },
  { icon: Globe, label: "Universal", href: "/universal" },
  { icon: Film, label: "Reels", href: "/reels" },
  { icon: Store, label: "Loja", href: "/marketplace" },
  { icon: MessageCircle, label: "Chat", href: "/chat" },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  if (!user) {
    return <div className="min-h-screen bg-background">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">
      {/* Mobile Top Nav */}
      <nav className="fixed top-0 left-0 right-0 h-14 bg-card border-b z-50 px-4 flex items-center justify-between md:hidden">
        <div className="font-serif font-bold text-base text-primary flex items-center gap-1">
          <span className="text-accent">CMJ</span>
          <span className="text-xs text-muted-foreground font-normal">· Conectando com Jesus</span>
        </div>
        <div className="flex items-center gap-3">
          {user.tipo_usuario === "admin" && (
            <Link href="/admin">
              <Shield className="w-5 h-5 text-accent" />
            </Link>
          )}
          <Link href="/wallet">
            <div className="flex items-center gap-1 text-xs font-semibold text-accent">
              <Wallet className="w-4 h-4" />
              {(user.saldo_moedas || 0).toLocaleString()}🪙
            </div>
          </Link>
          <Link href="/notifications">
            <Bell className="w-5 h-5" />
          </Link>
          <Link href={`/profile/${user.id}`}>
            <UserIcon className="w-5 h-5" />
          </Link>
        </div>
      </nav>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r bg-card h-screen sticky top-0 left-0 p-4">
        <div className="font-serif font-bold text-xl text-primary mb-8 mt-4 pl-2 leading-tight">
          Conectando o Mundo <span className="text-accent">com Jesus</span>
        </div>

        <div className="flex flex-col gap-1 flex-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                  isActive ? "bg-primary text-primary-foreground font-medium" : "hover:bg-muted text-muted-foreground"
                )}>
                <Icon className={cn("w-5 h-5", isActive && "text-accent")} />
                <span>{item.label}</span>
              </Link>
            );
          })}

          <Link href={`/profile/${user.id}`}
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
              location.startsWith("/profile") ? "bg-primary text-primary-foreground font-medium" : "hover:bg-muted text-muted-foreground"
            )}>
            <UserIcon className="w-5 h-5" />
            <span>Perfil</span>
          </Link>

          <Link href="/wallet"
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
              location === "/wallet" ? "bg-primary text-primary-foreground font-medium" : "hover:bg-muted text-muted-foreground"
            )}>
            <Wallet className="w-5 h-5" />
            <span>Carteira</span>
            <span className="ml-auto text-xs font-semibold text-accent">{(user.saldo_moedas || 0).toLocaleString()}🪙</span>
          </Link>

          {user.tipo_usuario === "admin" && (
            <Link href="/admin"
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                location === "/admin" ? "bg-primary text-primary-foreground font-medium" : "hover:bg-muted text-muted-foreground"
              )}>
              <Shield className="w-5 h-5 text-accent" />
              <span>Admin</span>
            </Link>
          )}
        </div>

        <div className="mt-auto pt-4 border-t space-y-2">
          <div className="px-4 py-2 text-xs text-muted-foreground">
            <p className="font-medium">{user.nome}</p>
            <p className="opacity-70">{user.email}</p>
            {user.tipo_usuario === "igreja" && <p className="text-accent font-medium">✝️ Igreja Verificada</p>}
          </div>
          <Button variant="ghost" className="justify-start gap-3 text-muted-foreground hover:text-foreground w-full" onClick={() => logout()}>
            <LogOut className="w-5 h-5" /> Sair
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 pb-16 md:pb-0 pt-14 md:pt-0 max-w-2xl mx-auto w-full md:border-x min-h-screen">
        {children}
      </main>

      {/* Desktop Right Sidebar */}
      <aside className="hidden lg:block w-72 h-screen sticky top-0 right-0 p-4 pt-8 space-y-4">
        <div className="bg-card rounded-xl border p-4 shadow-sm">
          <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">🔥 Em Alta Global</h3>
          <div className="space-y-3">
            {["Oração Pela Paz · 145k","Jovens com Propósito · 89k","Avivamento 2025 · 67k","Israel e Brasil Unidos · 43k"].map((t, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="text-accent text-sm font-bold">#{i + 1}</span>
                <div>
                  <p className="font-medium text-sm">{t.split("·")[0]}</p>
                  <p className="text-xs text-muted-foreground">{t.split("·")[1]} participando</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-xl border p-4 shadow-sm">
          <h3 className="font-semibold text-sm mb-3">🌍 Online Agora</h3>
          <div className="space-y-1 text-xs text-muted-foreground">
            {["🇧🇷 Brasil · 8.420","🇺🇸 EUA · 5.130","🇮🇱 Israel · 2.890","🇮🇳 Índia · 3.210","🇺🇦 Ucrânia · 1.540"].map((c, i) => (
              <div key={i} className="flex justify-between">
                <span>{c.split("·")[0]}</span>
                <span className="font-medium">{c.split("·")[1]}</span>
              </div>
            ))}
          </div>
        </div>
      </aside>

      {/* Mobile Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 h-16 bg-card border-t z-50 md:hidden flex items-center justify-around px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}
              className={cn("flex flex-col items-center gap-1 p-2 w-14 transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground")}>
              <Icon className={cn("w-6 h-6", isActive && "text-accent drop-shadow-md")} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
