import { Router } from "express";

const router = Router();

// Simple translation map for demo purposes
// In production, this would call Google Translate API or DeepL
const translationPhrases: Record<string, Record<string, string>> = {
  "pt-BR": {
    greeting: "Shalom! Paz de Deus!",
    amen: "Amém! Glória a Deus!",
    prayer: "Oramos por todos vocês!",
    bless: "Deus abençoe você!",
  },
  en: {
    greeting: "Shalom! God's peace!",
    amen: "Amen! Glory to God!",
    prayer: "We're praying for you all!",
    bless: "God bless you!",
  },
  es: {
    greeting: "¡Shalom! ¡La paz de Dios!",
    amen: "¡Amén! ¡Gloria a Dios!",
    prayer: "¡Oramos por todos ustedes!",
    bless: "¡Dios te bendiga!",
  },
  he: {
    greeting: "שלום! שלום האל!",
    amen: "!אמן! כבוד לאל",
    prayer: "אנחנו מתפללים בשבילכם",
    bless: "!ברוך השם",
  },
  hi: {
    greeting: "शालोम! परमेश्वर की शांति!",
    amen: "आमीन! परमेश्वर की महिमा!",
    prayer: "हम आप सभी के लिए प्रार्थना करते हैं!",
    bless: "परमेश्वर आपको आशीर्वाद दे!",
  },
  uk: {
    greeting: "Шалом! Мир Божий!",
    amen: "Амінь! Слава Богу!",
    prayer: "Ми молимося за вас усіх!",
    bless: "Нехай Бог благословить вас!",
  },
  zh: {
    greeting: "平安！上帝的平安！",
    amen: "阿门！荣耀归于神！",
    prayer: "我们为你们所有人祷告！",
    bless: "上帝保佑你！",
  },
  ar: {
    greeting: "شالوم! سلام الله!",
    amen: "آمين! المجد لله!",
    prayer: "نصلي لأجلكم جميعاً!",
    bless: "بارك الله فيك!",
  },
  tr: {
    greeting: "Şalom! Allah'ın barışı!",
    amen: "Amin! Allah'a şükür!",
    prayer: "Hepiniz için dua ediyoruz!",
    bless: "Allah sizi kutsasın!",
  },
  it: {
    greeting: "Shalom! La pace di Dio!",
    amen: "Amen! Gloria a Dio!",
    prayer: "Preghiamo per voi tutti!",
    bless: "Dio ti benedica!",
  },
  "pt-PT": {
    greeting: "Shalom! A paz de Deus!",
    amen: "Amém! Glória a Deus!",
    prayer: "Oramos por todos vocês!",
    bless: "Deus abençoe você!",
  },
};

// POST /api/translate
router.post("/", (req, res) => {
  const { texto, idioma_destino, idioma_origem } = req.body;
  // For demo: just mark it as translated and return with translation badge
  // In production: call real translation API
  const detected_lang = idioma_origem || "pt-BR";
  
  // Simple language detection heuristic
  let detected = detected_lang;
  if (/[א-ת]/.test(texto)) detected = "he";
  else if (/[А-Яа-яіїєё]/.test(texto)) detected = "uk";
  else if (/[\u4e00-\u9fff]/.test(texto)) detected = "zh";
  else if (/[अ-ह]/.test(texto)) detected = "hi";
  else if (/[ا-ي]/.test(texto)) detected = "ar";
  
  // For demo, return original text with a note
  let traduzido = texto;
  if (detected !== idioma_destino) {
    // Just append a translation note for demo
    const phrases = translationPhrases[idioma_destino];
    if (phrases && texto.toLowerCase().includes("amém")) {
      traduzido = phrases.amen || texto;
    } else if (texto.toLowerCase().includes("pray") || texto.toLowerCase().includes("ora")) {
      traduzido = phrases?.prayer || texto;
    } else {
      traduzido = texto; // Return original for now
    }
  }

  res.json({
    texto_traduzido: traduzido,
    idioma_origem: detected,
    idioma_destino,
  });
});

export default router;
