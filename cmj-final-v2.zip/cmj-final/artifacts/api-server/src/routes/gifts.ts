import { Router } from "express";
import { gifts, users, incGiftId, toPreview } from "../data/fakeData";
import { getUserFromRequest } from "./auth";

const router = Router();

// GET /api/gifts/history
router.get("/history", (req, res) => {
  const currentUser = getUserFromRequest(req);
  if (!currentUser) return res.status(401).json({ error: "Não autenticado" });
  const userGifts = gifts.filter((g) => g.destinatario.id === currentUser.id);
  res.json(userGifts);
});

// POST /api/gifts
router.post("/", (req, res) => {
  const currentUser = getUserFromRequest(req) || users[2];
  const { tipo, contexto, destinatario_id } = req.body;

  const VALORES: Record<string, number> = {
    pomba: 200, biblia: 500, coroa: 1000, maos: 300, coracao: 100,
  };
  const EMOJIS: Record<string, string> = {
    pomba: "🕊️", biblia: "📖", coroa: "👑", maos: "🙏", coracao: "🫀",
  };

  const valorMoedas = VALORES[tipo] || 100;
  const valorReal = valorMoedas * 1;
  const taxaAdmin = valorReal * 0.3;
  const valorLiquido = valorReal * 0.7;

  const destinatario = users.find((u) => u.id === destinatario_id) || users[1];

  // Debita do remetente
  if (currentUser.saldo_moedas >= valorMoedas) {
    currentUser.saldo_moedas -= valorMoedas;
    destinatario.saldo_moedas += Math.floor(valorMoedas * 0.7);
  }

  const newGift = {
    id: incGiftId(),
    tipo: tipo || "coracao",
    valor_moedas: valorMoedas,
    valor_real: valorReal,
    taxa_admin: taxaAdmin,
    valor_liquido: valorLiquido,
    contexto: contexto || "perfil",
    created_at: new Date().toISOString(),
    remetente: toPreview(currentUser),
    destinatario: toPreview(destinatario),
  };
  gifts.push(newGift as any);

  res.status(201).json({
    ...newGift,
    emoji: EMOJIS[tipo] || "🎁",
    message: `${EMOJIS[tipo] || "🎁"} Presente enviado com sucesso!`,
  });
});

export default router;
