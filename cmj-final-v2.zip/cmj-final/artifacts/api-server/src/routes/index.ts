import { Router } from "express";
import authRouter from "./auth";
import usersRouter from "./users";
import postsRouter from "./posts";
import reelsRouter from "./reels";
import marketplaceRouter from "./marketplace";
import chatRouter from "./chat";
import giftsRouter from "./gifts";
import notificationsRouter from "./notifications";
import adminRouter from "./admin";
import bannerRouter from "./banner";
import translateRouter from "./translate";
import healthRouter from "./health";

const router = Router();

router.use("/auth", authRouter);
router.use("/users", usersRouter);
router.use("/posts", postsRouter);
router.use("/reels", reelsRouter);
router.use("/marketplace", marketplaceRouter);
router.use("/chat", chatRouter);
router.use("/gifts", giftsRouter);
router.use("/notifications", notificationsRouter);
router.use("/admin", adminRouter);
router.use("/banner", bannerRouter);
router.use("/translate", translateRouter);
router.use("/health", healthRouter);

export default router;
