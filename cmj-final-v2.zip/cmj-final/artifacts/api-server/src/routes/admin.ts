import { Router } from "express";
import { users, posts, gifts, withdrawals, blacklist, notifications, engagementConfig, incNotificationId } from "../data/fakeData";

const router = Router();

// GET /api/admin/stats
router.get("/stats", (_req, res) => {
  const totalUsers = users.length;
  const usuariosAtivosHoje = Math.floor(totalUsers * 0.73);
  const usuariosAtivosMes = Math.floor(totalUsers * 0.92);
  const totalDepositado = gifts.reduce((s, g) => s + g.valor_real, 0) + 45820.50;
  const totalSacado = withdrawals.filter((w) => w.status === "aprovado").reduce((s, w) => s + w.valor, 0) + 12340.00;
  const totalIgrejas = users.filter((u) => u.tipo_usuario === "igreja").length;

  // Chart data — last 7 days
  const chartCadastros = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return { label: d.toLocaleDateString("pt-BR", { weekday: "short" }), value: Math.floor(Math.random() * 150) + 50 };
  });
  const chartFinanceiro = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return { label: d.toLocaleDateString("pt-BR", { weekday: "short" }), value: Math.floor(Math.random() * 5000) + 1000 };
  });

  res.json({
    total_usuarios: totalUsers,
    usuarios_ativos_hoje: usuariosAtivosHoje,
    usuarios_ativos_mes: usuariosAtivosMes,
    total_depositado: totalDepositado,
    total_sacado: totalSacado,
    total_presentes: gifts.length + 1240,
    total_posts: posts.length + 8920,
    total_igrejas: totalIgrejas,
    chart_cadastros: chartCadastros,
    chart_financeiro: chartFinanceiro,
  });
});

// GET /api/admin/withdrawals
router.get("/withdrawals", (_req, res) => {
  res.json([...withdrawals].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));
});

// POST /api/admin/withdrawals/:id/approve
router.post("/withdrawals/:id/approve", (req, res) => {
  const w = withdrawals.find((x) => x.id === parseInt(req.params.id));
  if (!w) return res.status(404).json({ error: "Saque não encontrado" });
  w.status = "aprovado";
  res.json({ message: `Saque de R$ ${w.valor} aprovado para ${w.usuario.nome}` });
});

// GET /api/admin/engagement
router.get("/engagement", (_req, res) => {
  res.json(engagementConfig);
});

// PATCH /api/admin/engagement
router.patch("/engagement", (req, res) => {
  const { views_multiplier, curtidas_multiplier, comentarios_ativos } = req.body;
  if (views_multiplier !== undefined) engagementConfig.views_multiplier = Number(views_multiplier);
  if (curtidas_multiplier !== undefined) engagementConfig.curtidas_multiplier = Number(curtidas_multiplier);
  if (comentarios_ativos !== undefined) engagementConfig.comentarios_ativos = Boolean(comentarios_ativos);
  engagementConfig.updated_at = new Date().toISOString();
  res.json(engagementConfig);
});

// POST /api/admin/notify
router.post("/notify", (req, res) => {
  const { titulo, mensagem, modo, destinatario_id } = req.body;
  const newNotif = {
    id: incNotificationId(),
    titulo,
    mensagem,
    lida: false,
    tipo: "harpa",
    created_at: new Date().toISOString(),
  };
  notifications.push(newNotif);
  const target = modo === "global" ? "todos os usuários" : `usuário #${destinatario_id}`;
  res.json({ message: `🎺 Harpa Mensageira: Notificação enviada para ${target}!` });
});

// GET /api/admin/blacklist
router.get("/blacklist", (_req, res) => {
  res.json(blacklist);
});

// GET /api/admin/users
router.get("/users", (req, res) => {
  const { search, status } = req.query as Record<string, string>;
  let result = [...users];
  if (search) {
    const q = search.toLowerCase();
    result = result.filter((u) => u.nome.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
  }
  if (status) {
    result = result.filter((u) => u.status === status);
  }
  res.json(result.map((u) => ({
    id: u.id,
    nome: u.nome,
    email: u.email,
    tipo_usuario: u.tipo_usuario,
    bio: u.bio,
    foto_url: u.foto_url,
    capa_url: u.capa_url,
    idioma: u.idioma,
    status: u.status,
    saldo_moedas: u.saldo_moedas,
    amigos_count: u.amigos_count,
    igrejas_count: u.igrejas_count,
    seguidores_count: u.seguidores_count,
    posts_count: u.posts_count,
    selo_autenticidade: u.selo_autenticidade,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: u.created_at,
  })));
});

export default router;
