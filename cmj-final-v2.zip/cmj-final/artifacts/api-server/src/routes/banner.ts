import { Router } from "express";
import { banner } from "../data/fakeData";

const router = Router();

// GET /api/banner
router.get("/", (_req, res) => {
  res.json(banner);
});

// PATCH /api/banner
router.patch("/", (req, res) => {
  const { titulo, subtitulo, imagem_url, cta_texto } = req.body;
  if (titulo !== undefined) banner.titulo = titulo;
  if (subtitulo !== undefined) banner.subtitulo = subtitulo;
  if (imagem_url !== undefined) banner.imagem_url = imagem_url;
  if (cta_texto !== undefined) banner.cta_texto = cta_texto;
  res.json(banner);
});

export default router;
