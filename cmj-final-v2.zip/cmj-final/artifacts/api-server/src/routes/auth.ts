import { Router } from "express";
import { users, incUserId, toPreview, type User } from "../data/fakeData";

const router = Router();

// Simple JWT-like token (base64 encoded user id)
function makeToken(userId: number): string {
  return Buffer.from(`cmj:${userId}:${Date.now()}`).toString("base64");
}

function parseToken(token: string): number | null {
  try {
    const decoded = Buffer.from(token, "base64").toString("utf-8");
    const parts = decoded.split(":");
    if (parts[0] !== "cmj") return null;
    return parseInt(parts[1], 10);
  } catch {
    return null;
  }
}

export function getUserFromRequest(req: any): User | null {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith("Bearer ")) return null;
  const token = auth.slice(7);
  const userId = parseToken(token);
  if (!userId) return null;
  return users.find((u) => u.id === userId) || null;
}

function userToResponse(u: User) {
  return {
    id: u.id,
    nome: u.nome,
    email: u.email,
    tipo_usuario: u.tipo_usuario,
    bio: u.bio,
    foto_url: u.foto_url,
    capa_url: u.capa_url,
    idioma: u.idioma,
    status: u.status,
    saldo_moedas: u.saldo_moedas,
    amigos_count: u.amigos_count,
    igrejas_count: u.igrejas_count,
    seguidores_count: u.seguidores_count,
    posts_count: u.posts_count,
    selo_autenticidade: u.selo_autenticidade,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: u.created_at,
  };
}

// POST /api/auth/login
router.post("/login", (req, res) => {
  const { email, senha } = req.body;
  const user = users.find((u) => u.email === email);
  if (!user) {
    return res.status(401).json({ error: "E-mail não encontrado" });
  }
  if (user.senha_hash !== senha) {
    return res.status(401).json({ error: "Senha incorreta" });
  }
  if (user.status === "banido") {
    return res.status(403).json({ error: "Conta banida da plataforma" });
  }
  const token = makeToken(user.id);
  return res.json({ token, user: userToResponse(user) });
});

// POST /api/auth/register
router.post("/register", (req, res) => {
  const { nome, email, senha, tipo_usuario, idioma } = req.body;
  if (users.find((u) => u.email === email)) {
    return res.status(400).json({ error: "E-mail já cadastrado" });
  }
  const newId = incUserId();
  const newUser: User = {
    id: newId,
    nome,
    email,
    senha_hash: senha,
    tipo_usuario: tipo_usuario || "comum",
    bio: null,
    foto_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${newId}&backgroundColor=b6e3f4`,
    capa_url: null,
    idioma: idioma || "pt-BR",
    status: "ativo",
    saldo_moedas: 50, // welcome bonus
    amigos_count: 0,
    igrejas_count: 0,
    seguidores_count: 0,
    posts_count: 0,
    selo_autenticidade: tipo_usuario === "igreja",
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: new Date().toISOString(),
  };
  users.push(newUser);
  const token = makeToken(newUser.id);
  return res.status(201).json({ token, user: userToResponse(newUser) });
});

// POST /api/auth/logout
router.post("/logout", (_req, res) => {
  res.json({ message: "Logout realizado com sucesso" });
});

// GET /api/auth/me
router.get("/me", (req, res) => {
  const user = getUserFromRequest(req);
  if (!user) return res.status(401).json({ error: "Não autenticado" });
  return res.json(userToResponse(user));
});

export { makeToken, parseToken, userToResponse };
export default router;
