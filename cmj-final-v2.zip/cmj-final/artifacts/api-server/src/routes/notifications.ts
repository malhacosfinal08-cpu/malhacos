import { Router } from "express";
import { notifications } from "../data/fakeData";

const router = Router();

// GET /api/notifications
router.get("/", (_req, res) => {
  const result = [...notifications].sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );
  res.json(result);
});

export default router;
