import { Router } from "express";
import { reels, users, engagementConfig, incReelId, toPreview } from "../data/fakeData";
import { getUserFromRequest } from "./auth";

const router = Router();

function applyEngagement(reel: any) {
  return {
    ...reel,
    views: Math.floor(reel.views * engagementConfig.views_multiplier),
    curtidas: Math.floor(reel.curtidas * engagementConfig.curtidas_multiplier),
  };
}

// GET /api/reels
router.get("/", (req, res) => {
  const { limit = "20", offset = "0" } = req.query as Record<string, string>;
  const result = reels
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(parseInt(offset), parseInt(offset) + parseInt(limit));
  res.json(result.map(applyEngagement));
});

// POST /api/reels
router.post("/", (req, res) => {
  const currentUser = getUserFromRequest(req);
  const fallbackUser = users[2];
  const author = currentUser || fallbackUser;
  const { titulo, embed_url, plataforma, thumbnail_url } = req.body;
  const newReel = {
    id: incReelId(),
    titulo,
    embed_url,
    plataforma,
    thumbnail_url: thumbnail_url || null,
    curtidas: 0,
    views: 10,
    liked: false,
    created_at: new Date().toISOString(),
    usuario: toPreview(author),
  };
  reels.unshift(newReel as any);
  res.status(201).json(newReel);
});

// POST /api/reels/:id/like
router.post("/:id/like", (req, res) => {
  const reel = reels.find((r) => r.id === parseInt(req.params.id));
  if (!reel) return res.status(404).json({ error: "Reel não encontrado" });
  if (reel.liked) {
    reel.curtidas -= 1;
    reel.liked = false;
  } else {
    reel.curtidas += 1;
    reel.liked = true;
  }
  res.json({ message: reel.liked ? "Curtido!" : "Curtida removida" });
});

export default router;
