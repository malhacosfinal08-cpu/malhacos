import { Router } from "express";
import { posts, comments, users, engagementConfig, incPostId, incCommentId, toPreview } from "../data/fakeData";
import { getUserFromRequest } from "./auth";

const router = Router();

function applyEngagement(post: any) {
  const vm = engagementConfig.views_multiplier;
  const cm = engagementConfig.curtidas_multiplier;
  return {
    ...post,
    views: Math.floor(post.views * vm),
    curtidas: Math.floor(post.curtidas * cm),
  };
}

// GET /api/posts
router.get("/", (req, res) => {
  const { tipo, limit = "20", offset = "0" } = req.query as Record<string, string>;
  let result = [...posts];
  if (tipo === "conexoes") {
    result = result.filter((p) => [2, 3, 4, 6, 11].includes(p.usuario_id));
  } else if (tipo === "universal") {
    // all
  }
  result = result
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(parseInt(offset), parseInt(offset) + parseInt(limit));

  res.json(result.map(applyEngagement));
});

// POST /api/posts
router.post("/", (req, res) => {
  const currentUser = getUserFromRequest(req);
  const fallbackUser = users[2]; // Default user for demo
  const author = currentUser || fallbackUser;
  const { tipo, conteudo, media_url } = req.body;
  const newPost = {
    id: incPostId(),
    usuario_id: author.id,
    tipo: tipo || "texto",
    conteudo,
    media_url: media_url || null,
    curtidas: 0,
    comentarios_count: 0,
    views: 1,
    liked: false,
    created_at: new Date().toISOString(),
    usuario: toPreview(author),
  };
  posts.unshift(newPost as any);
  author.posts_count += 1;
  res.status(201).json(newPost);
});

// GET /api/posts/:id
router.get("/:id", (req, res) => {
  const post = posts.find((p) => p.id === parseInt(req.params.id));
  if (!post) return res.status(404).json({ error: "Post não encontrado" });
  res.json(applyEngagement(post));
});

// DELETE /api/posts/:id
router.delete("/:id", (req, res) => {
  const idx = posts.findIndex((p) => p.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: "Post não encontrado" });
  posts.splice(idx, 1);
  res.json({ message: "Post removido com sucesso" });
});

// POST /api/posts/:id/like
router.post("/:id/like", (req, res) => {
  const post = posts.find((p) => p.id === parseInt(req.params.id));
  if (!post) return res.status(404).json({ error: "Post não encontrado" });
  if (post.liked) {
    post.curtidas -= 1;
    post.liked = false;
  } else {
    post.curtidas += 1;
    post.liked = true;
  }
  res.json({ message: post.liked ? "Curtido!" : "Curtida removida" });
});

// GET /api/posts/:id/comments
router.get("/:id/comments", (req, res) => {
  const postId = parseInt(req.params.id);
  const postComments = comments.filter((c) => c.post_id === postId);
  // Add fake comments from engagement if enabled
  if (engagementConfig.comentarios_ativos && postComments.length < 3) {
    const fakeComments = [
      { id: incCommentId(), post_id: postId, usuario_id: 4, conteudo: "Amém! Gloria a Deus! 🙏", curtidas: Math.floor(Math.random() * 200), presente_emoji: null, created_at: new Date(Date.now() - Math.random() * 3600000).toISOString(), usuario: toPreview(users[3]) },
      { id: incCommentId(), post_id: postId, usuario_id: 8, conteudo: "Hallelujah from India! 🇮🇳❤️", curtidas: Math.floor(Math.random() * 150), presente_emoji: null, created_at: new Date(Date.now() - Math.random() * 7200000).toISOString(), usuario: toPreview(users[7]) },
    ];
    return res.json([...postComments, ...fakeComments]);
  }
  res.json(postComments);
});

// POST /api/posts/:id/comments
router.post("/:id/comments", (req, res) => {
  const currentUser = getUserFromRequest(req);
  const fallbackUser = users[2];
  const author = currentUser || fallbackUser;
  const postId = parseInt(req.params.id);
  const post = posts.find((p) => p.id === postId);
  if (!post) return res.status(404).json({ error: "Post não encontrado" });
  const { conteudo, presente_emoji } = req.body;
  const newComment = {
    id: incCommentId(),
    post_id: postId,
    usuario_id: author.id,
    conteudo,
    curtidas: 0,
    presente_emoji: presente_emoji || null,
    created_at: new Date().toISOString(),
    usuario: toPreview(author),
  };
  comments.push(newComment as any);
  post.comentarios_count += 1;
  res.status(201).json(newComment);
});

export default router;
