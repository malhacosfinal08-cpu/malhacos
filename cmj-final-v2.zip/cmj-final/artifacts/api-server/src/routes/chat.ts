import { Router } from "express";
import { universalMessages, privateMessages, users, incMessageId, toPreview } from "../data/fakeData";
import { getUserFromRequest } from "./auth";

const router = Router();

// GET /api/chat/universal
router.get("/universal", (req, res) => {
  const { limit = "50" } = req.query as Record<string, string>;
  const result = [...universalMessages]
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
    .slice(-parseInt(limit));
  res.json(result);
});

// POST /api/chat/universal
router.post("/universal", (req, res) => {
  const currentUser = getUserFromRequest(req);
  const fallbackUser = users[2];
  const author = currentUser || fallbackUser;
  const { conteudo, idioma, presente_emoji } = req.body;
  const prioridade = !!presente_emoji;
  const newMsg = {
    id: incMessageId(),
    conteudo,
    conteudo_original: conteudo,
    idioma_original: idioma || "pt-BR",
    prioridade,
    presente_emoji: presente_emoji || null,
    created_at: new Date().toISOString(),
    usuario: toPreview(author),
  };
  if (prioridade) {
    universalMessages.unshift(newMsg as any);
  } else {
    universalMessages.push(newMsg as any);
  }
  res.status(201).json(newMsg);
});

// GET /api/chat/private/:userId
router.get("/private/:userId", (req, res) => {
  const currentUser = getUserFromRequest(req);
  const myId = currentUser?.id || 3;
  const otherId = parseInt(req.params.userId);
  const key1 = `${myId}-${otherId}`;
  const key2 = `${otherId}-${myId}`;
  const msgs = privateMessages[key1] || privateMessages[key2] || [];
  res.json(msgs.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()));
});

// POST /api/chat/private/:userId
router.post("/private/:userId", (req, res) => {
  const currentUser = getUserFromRequest(req);
  const myId = currentUser?.id || 3;
  const otherId = parseInt(req.params.userId);
  const author = users.find((u) => u.id === myId) || users[2];
  const { conteudo, idioma, presente_emoji } = req.body;
  const key = `${myId}-${otherId}`;
  if (!privateMessages[key]) {
    privateMessages[key] = [];
  }
  const newMsg = {
    id: incMessageId(),
    conteudo,
    conteudo_original: conteudo,
    idioma_original: idioma || "pt-BR",
    prioridade: !!presente_emoji,
    presente_emoji: presente_emoji || null,
    created_at: new Date().toISOString(),
    usuario: toPreview(author),
  };
  privateMessages[key].push(newMsg as any);
  res.status(201).json(newMsg);
});

export default router;
