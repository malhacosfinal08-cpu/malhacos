import { Router } from "express";
import { users, blacklist, incUserId, toPreview } from "../data/fakeData";
import { getUserFromRequest, userToResponse } from "./auth";

const router = Router();

function enrichUser(u: any, currentUser: any) {
  return {
    ...userToResponse(u),
    is_seguindo: Math.random() > 0.7,
    is_amigo: u.is_amigo ?? false,
    is_membro: u.is_membro ?? false,
  };
}

// GET /api/users
router.get("/", (req, res) => {
  const { search, tipo, limit = "20" } = req.query as Record<string, string>;
  let result = [...users];
  if (search) {
    const q = search.toLowerCase();
    result = result.filter((u) => u.nome.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
  }
  if (tipo) {
    result = result.filter((u) => u.tipo_usuario === tipo);
  }
  result = result.slice(0, parseInt(limit));
  res.json(result.map((u) => enrichUser(u, null)));
});

// GET /api/users/:id
router.get("/:id", (req, res) => {
  const user = users.find((u) => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
  res.json(enrichUser(user, null));
});

// PATCH /api/users/:id
router.patch("/:id", (req, res) => {
  const user = users.find((u) => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
  const { nome, bio, foto_url, capa_url, idioma, status } = req.body;
  if (nome !== undefined) user.nome = nome;
  if (bio !== undefined) user.bio = bio;
  if (foto_url !== undefined) user.foto_url = foto_url;
  if (capa_url !== undefined) user.capa_url = capa_url;
  if (idioma !== undefined) user.idioma = idioma;
  if (status !== undefined) user.status = status;
  res.json(enrichUser(user, null));
});

// POST /api/users/:id/follow
router.post("/:id/follow", (req, res) => {
  const target = users.find((u) => u.id === parseInt(req.params.id));
  if (!target) return res.status(404).json({ error: "Usuário não encontrado" });
  target.seguidores_count += 1;
  res.json({ message: `Você agora segue ${target.nome}` });
});

// POST /api/users/:id/add-friend
router.post("/:id/add-friend", (req, res) => {
  const target = users.find((u) => u.id === parseInt(req.params.id));
  if (!target) return res.status(404).json({ error: "Usuário não encontrado" });
  target.amigos_count += 1;
  res.json({ message: `Solicitação de amizade enviada para ${target.nome}` });
});

// POST /api/users/:id/join-church
router.post("/:id/join-church", (req, res) => {
  const target = users.find((u) => u.id === parseInt(req.params.id));
  if (!target) return res.status(404).json({ error: "Igreja não encontrada" });
  target.seguidores_count += 1;
  res.json({ message: `Você se tornou membro de ${target.nome}` });
});

// POST /api/users/:id/ban
router.post("/:id/ban", (req, res) => {
  const user = users.find((u) => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
  const { motivo } = req.body;
  user.status = "banido";
  blacklist.push({
    id: blacklist.length + 1,
    cpf: null,
    email: user.email,
    telefone: null,
    motivo: motivo || "Banido pelo administrador",
    created_at: new Date().toISOString(),
  });
  res.json({ message: `Usuário ${user.nome} foi banido e adicionado à blacklist` });
});

// POST /api/users/:id/reset-password
router.post("/:id/reset-password", (req, res) => {
  const user = users.find((u) => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
  const { nova_senha } = req.body;
  user.senha_hash = nova_senha;
  res.json({ message: `Senha de ${user.nome} redefinida com sucesso` });
});

// POST /api/users/:id/adjust-balance
router.post("/:id/adjust-balance", (req, res) => {
  const user = users.find((u) => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
  const { valor } = req.body;
  user.saldo_moedas += Number(valor);
  if (user.saldo_moedas < 0) user.saldo_moedas = 0;
  res.json(enrichUser(user, null));
});

export default router;
