import { Router } from "express";
import { marketplaceItems, users, incMarketplaceId, toPreview } from "../data/fakeData";
import { getUserFromRequest } from "./auth";

const router = Router();

// GET /api/marketplace
router.get("/", (req, res) => {
  const { categoria, search, limit = "20" } = req.query as Record<string, string>;
  let result = [...marketplaceItems];
  if (categoria) {
    result = result.filter((i) => i.categoria.toLowerCase() === categoria.toLowerCase());
  }
  if (search) {
    const q = search.toLowerCase();
    result = result.filter((i) => i.titulo.toLowerCase().includes(q) || i.descricao.toLowerCase().includes(q));
  }
  result = result.slice(0, parseInt(limit));
  res.json(result);
});

// POST /api/marketplace
router.post("/", (req, res) => {
  const currentUser = getUserFromRequest(req);
  const fallbackUser = users[2];
  const author = currentUser || fallbackUser;
  const { titulo, descricao, preco, categoria, foto_url, condicao } = req.body;
  const newItem = {
    id: incMarketplaceId(),
    titulo,
    descricao,
    preco: Number(preco),
    categoria,
    foto_url: foto_url || null,
    condicao: condicao || "novo",
    created_at: new Date().toISOString(),
    usuario: toPreview(author),
  };
  marketplaceItems.unshift(newItem as any);
  res.status(201).json(newItem);
});

// GET /api/marketplace/:id
router.get("/:id", (req, res) => {
  const item = marketplaceItems.find((i) => i.id === parseInt(req.params.id));
  if (!item) return res.status(404).json({ error: "Item não encontrado" });
  res.json(item);
});

export default router;
