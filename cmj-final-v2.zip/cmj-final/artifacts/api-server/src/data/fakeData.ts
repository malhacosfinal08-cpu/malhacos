// ============================================================
// FAKE IN-MEMORY DATA — Conectando o Mundo com Jesus
// ============================================================

export interface UserPreview {
  id: number;
  nome: string;
  foto_url: string | null;
  tipo_usuario: string;
  selo_autenticidade: boolean;
}

export interface User {
  id: number;
  nome: string;
  email: string;
  senha_hash: string;
  tipo_usuario: "comum" | "igreja" | "admin";
  bio: string | null;
  foto_url: string | null;
  capa_url: string | null;
  idioma: string;
  status: "ativo" | "em_analise" | "banido";
  saldo_moedas: number;
  amigos_count: number;
  igrejas_count: number;
  seguidores_count: number;
  posts_count: number;
  selo_autenticidade: boolean;
  is_seguindo: boolean;
  is_amigo: boolean;
  is_membro: boolean;
  created_at: string;
}

export interface Post {
  id: number;
  usuario_id: number;
  tipo: "texto" | "imagem" | "reel" | "live";
  conteudo: string;
  media_url: string | null;
  curtidas: number;
  comentarios_count: number;
  views: number;
  liked: boolean;
  created_at: string;
  usuario: UserPreview;
}

export interface Comment {
  id: number;
  post_id: number;
  usuario_id: number;
  conteudo: string;
  curtidas: number;
  presente_emoji: string | null;
  created_at: string;
  usuario: UserPreview;
}

export interface Reel {
  id: number;
  titulo: string;
  embed_url: string;
  plataforma: "youtube" | "instagram" | "tiktok";
  thumbnail_url: string | null;
  curtidas: number;
  views: number;
  liked: boolean;
  created_at: string;
  usuario: UserPreview;
}

export interface MarketplaceItem {
  id: number;
  titulo: string;
  descricao: string;
  preco: number;
  categoria: string;
  foto_url: string | null;
  condicao: string;
  created_at: string;
  usuario: UserPreview;
}

export interface ChatMessage {
  id: number;
  conteudo: string;
  conteudo_original: string;
  idioma_original: string;
  prioridade: boolean;
  presente_emoji: string | null;
  created_at: string;
  usuario: UserPreview;
}

export interface Gift {
  id: number;
  tipo: "biblia" | "pomba" | "coroa" | "maos" | "coracao";
  valor_moedas: number;
  valor_real: number;
  taxa_admin: number;
  valor_liquido: number;
  contexto: "live" | "perfil" | "comentario";
  created_at: string;
  remetente: UserPreview;
  destinatario: UserPreview;
}

export interface Withdrawal {
  id: number;
  valor: number;
  chave_pix: string;
  status: "pendente" | "aprovado" | "rejeitado";
  automatico: boolean;
  created_at: string;
  usuario: UserPreview;
}

export interface BlacklistEntry {
  id: number;
  cpf: string | null;
  email: string;
  telefone: string | null;
  motivo: string;
  created_at: string;
}

export interface Notification {
  id: number;
  titulo: string;
  mensagem: string;
  lida: boolean;
  tipo: string;
  created_at: string;
}

export interface EngagementConfig {
  id: number;
  views_multiplier: number;
  curtidas_multiplier: number;
  comentarios_ativos: boolean;
  updated_at: string;
}

export interface Banner {
  id: number;
  titulo: string;
  subtitulo: string;
  imagem_url: string;
  cta_texto: string;
}

function daysAgo(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString();
}

function hoursAgo(h: number): string {
  const d = new Date();
  d.setHours(d.getHours() - h);
  return d.toISOString();
}

function minutesAgo(m: number): string {
  const d = new Date();
  d.setMinutes(d.getMinutes() - m);
  return d.toISOString();
}

// ============================================================
// USERS
// ============================================================
export const users: User[] = [
  {
    id: 1,
    nome: "Admin Master",
    email: "admin@cmj.com",
    senha_hash: "admin123",
    tipo_usuario: "admin",
    bio: "Administrador da plataforma Conectando o Mundo com Jesus",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=admin&backgroundColor=b6e3f4",
    capa_url: null,
    idioma: "pt-BR",
    status: "ativo",
    saldo_moedas: 99999,
    amigos_count: 0,
    igrejas_count: 0,
    seguidores_count: 15420,
    posts_count: 0,
    selo_autenticidade: true,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(365),
  },
  {
    id: 2,
    nome: "Igreja Batista de Jerusalém",
    email: "ibj@jerusalem.com",
    senha_hash: "senha123",
    tipo_usuario: "igreja",
    bio: "Igreja fundada em 1948, conectando fiéis do mundo todo através da fé em Cristo Jesus.",
    foto_url: "https://api.dicebear.com/7.x/initials/svg?seed=IBJ&backgroundColor=ffd700&fontColor=000080",
    capa_url: "https://images.unsplash.com/photo-1438232992991-995b671e5d96?w=800",
    idioma: "he",
    status: "ativo",
    saldo_moedas: 12450,
    amigos_count: 0,
    igrejas_count: 0,
    seguidores_count: 45820,
    posts_count: 234,
    selo_autenticidade: true,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(180),
  },
  {
    id: 3,
    nome: "Pastor Marcos Oliveira",
    email: "marcos@email.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "🙏 Servo do Senhor | Pastor há 20 anos | Brasil 🇧🇷",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=marcos&backgroundColor=b6e3f4",
    capa_url: null,
    idioma: "pt-BR",
    status: "ativo",
    saldo_moedas: 850,
    amigos_count: 2340,
    igrejas_count: 2,
    seguidores_count: 18900,
    posts_count: 456,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(90),
  },
  {
    id: 4,
    nome: "Sarah Johnson",
    email: "sarah@email.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "Worship leader | Gospel singer | USA 🇺🇸",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=sarah&backgroundColor=ffd5dc",
    capa_url: null,
    idioma: "en",
    status: "ativo",
    saldo_moedas: 320,
    amigos_count: 890,
    igrejas_count: 1,
    seguidores_count: 12500,
    posts_count: 189,
    selo_autenticidade: false,
    is_seguindo: true,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(60),
  },
  {
    id: 5,
    nome: "הרב שמעון כהן",
    email: "shimon@israel.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "מנהיג רוחני | ישראל 🇮🇱",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=shimon&backgroundColor=c0aede",
    capa_url: null,
    idioma: "he",
    status: "ativo",
    saldo_moedas: 1200,
    amigos_count: 560,
    igrejas_count: 1,
    seguidores_count: 8900,
    posts_count: 120,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(45),
  },
  {
    id: 6,
    nome: "Padre Antonio García",
    email: "antonio@spain.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "Sacerdote | España 🇪🇸 | Servidor de Dios",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=antonio&backgroundColor=d1d4f9",
    capa_url: null,
    idioma: "es",
    status: "ativo",
    saldo_moedas: 450,
    amigos_count: 1200,
    igrejas_count: 3,
    seguidores_count: 22400,
    posts_count: 312,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: true,
    is_membro: false,
    created_at: daysAgo(72),
  },
  {
    id: 7,
    nome: "Natasha Petrenko",
    email: "natasha@ukraine.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "Христіанка | Украïна 🇺🇦 | Хваліть Господа!",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=natasha&backgroundColor=b6e3f4",
    capa_url: null,
    idioma: "uk",
    status: "ativo",
    saldo_moedas: 230,
    amigos_count: 780,
    igrejas_count: 1,
    seguidores_count: 6700,
    posts_count: 89,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(30),
  },
  {
    id: 8,
    nome: "Rev. Priya Sharma",
    email: "priya@india.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "Christian leader | India 🇮🇳 | Hallelujah!",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=priya&backgroundColor=ffd5dc",
    capa_url: null,
    idioma: "hi",
    status: "ativo",
    saldo_moedas: 680,
    amigos_count: 1450,
    igrejas_count: 2,
    seguidores_count: 31200,
    posts_count: 267,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(55),
  },
  {
    id: 9,
    nome: "Igreja Mundial da Graça",
    email: "img@graca.com",
    senha_hash: "senha123",
    tipo_usuario: "igreja",
    bio: "A maior Igreja do Brasil! Conectando almas ao redor do mundo.",
    foto_url: "https://api.dicebear.com/7.x/initials/svg?seed=IMG&backgroundColor=ffd700&fontColor=000080",
    capa_url: "https://images.unsplash.com/photo-1565021073741-9e43b5f5dbfd?w=800",
    idioma: "pt-BR",
    status: "ativo",
    saldo_moedas: 89500,
    amigos_count: 0,
    igrejas_count: 0,
    seguidores_count: 234000,
    posts_count: 1890,
    selo_autenticidade: true,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(200),
  },
  {
    id: 10,
    nome: "Liu Wei",
    email: "liu@china.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "基督徒 | 中国 🇨🇳 | 哈利路亚！",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=liu&backgroundColor=c0aede",
    capa_url: null,
    idioma: "zh",
    status: "ativo",
    saldo_moedas: 520,
    amigos_count: 340,
    igrejas_count: 1,
    seguidores_count: 5400,
    posts_count: 78,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(20),
  },
  {
    id: 11,
    nome: "Maria da Graça",
    email: "maria@email.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "Filha do Rei 👑 | Levita | São Paulo, Brasil 🇧🇷",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=maria&backgroundColor=ffd5dc",
    capa_url: null,
    idioma: "pt-BR",
    status: "ativo",
    saldo_moedas: 120,
    amigos_count: 456,
    igrejas_count: 1,
    seguidores_count: 3200,
    posts_count: 67,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: true,
    is_membro: false,
    created_at: daysAgo(15),
  },
  {
    id: 12,
    nome: "Ahmet Yilmaz",
    email: "ahmet@turkey.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "Hristiyan | Türkiye 🇹🇷 | Allah'a şükür!",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=ahmet&backgroundColor=d1d4f9",
    capa_url: null,
    idioma: "tr",
    status: "ativo",
    saldo_moedas: 380,
    amigos_count: 289,
    igrejas_count: 1,
    seguidores_count: 4100,
    posts_count: 45,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(10),
  },
  {
    id: 13,
    nome: "Sofia Romano",
    email: "sofia@italy.com",
    senha_hash: "senha123",
    tipo_usuario: "comum",
    bio: "Cristiana | Italia 🇮🇹 | Lode al Signore!",
    foto_url: "https://api.dicebear.com/7.x/avataaars/svg?seed=sofia&backgroundColor=ffd5dc",
    capa_url: null,
    idioma: "it",
    status: "ativo",
    saldo_moedas: 290,
    amigos_count: 567,
    igrejas_count: 2,
    seguidores_count: 7800,
    posts_count: 123,
    selo_autenticidade: false,
    is_seguindo: false,
    is_amigo: false,
    is_membro: false,
    created_at: daysAgo(25),
  },
];

function toPreview(u: User): UserPreview {
  return { id: u.id, nome: u.nome, foto_url: u.foto_url, tipo_usuario: u.tipo_usuario, selo_autenticidade: u.selo_autenticidade };
}

// ============================================================
// POSTS
// ============================================================
export const posts: Post[] = [
  {
    id: 1,
    usuario_id: 2,
    tipo: "texto",
    conteudo: "🙌 Shalom queridos irmãos! Hoje celebramos mais um dia de graça. A paz de Deus que excede todo entendimento guarde os vossos corações! Oramos por todos vocês ao redor do mundo. Traduzido automaticamente por IA 🌍",
    media_url: null,
    curtidas: 12480,
    comentarios_count: 342,
    views: 45200,
    liked: false,
    created_at: hoursAgo(2),
    usuario: toPreview(users[1]),
  },
  {
    id: 2,
    usuario_id: 3,
    tipo: "imagem",
    conteudo: "Que bênção imensa poder conectar com irmãos de tantas nações! Hoje recebi mensagens de Israel, India e Ucrânia — todos unidos em Cristo! Gloria a Deus! 🙏❤️",
    media_url: "https://images.unsplash.com/photo-1474552226712-ac0f0961a954?w=600",
    curtidas: 8920,
    comentarios_count: 218,
    views: 32100,
    liked: true,
    created_at: hoursAgo(5),
    usuario: toPreview(users[2]),
  },
  {
    id: 3,
    usuario_id: 4,
    tipo: "texto",
    conteudo: "God's love knows no borders! Just connected with brothers and sisters from Brazil, Israel, India, Ukraine and China all in one platform. This is what heaven will look like 🌍✨ Praise the Lord!",
    media_url: null,
    curtidas: 15600,
    comentarios_count: 567,
    views: 78900,
    liked: false,
    created_at: hoursAgo(8),
    usuario: toPreview(users[3]),
  },
  {
    id: 4,
    usuario_id: 5,
    tipo: "texto",
    conteudo: "ברוך השם! שמחתי מאוד להצטרף לפלטפורמה הזו ולהתחבר עם אחים ואחיות מכל העולם. ישו אוהב אתכם! אמן 🕊️",
    media_url: null,
    curtidas: 6780,
    comentarios_count: 189,
    views: 23400,
    liked: false,
    created_at: hoursAgo(12),
    usuario: toPreview(users[4]),
  },
  {
    id: 5,
    usuario_id: 9,
    tipo: "imagem",
    conteudo: "🔥 AVIVAMENTO MUNDIAL! Nossa conferência global reuniu mais de 50.000 fiéis online de 142 países! O Espírito Santo está se movendo! Compartilhe e faça parte desta corrente de fé! #ConectandoOMundoComJesus",
    media_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600",
    curtidas: 45200,
    comentarios_count: 1890,
    views: 234000,
    liked: false,
    created_at: hoursAgo(18),
    usuario: toPreview(users[8]),
  },
  {
    id: 6,
    usuario_id: 8,
    tipo: "texto",
    conteudo: "Hallelujah! Friends from Brazil prayed for my ministry in India today through this platform. The Holy Spirit has no borders! Thank you Jesus! 🙏🇮🇳🇧🇷",
    media_url: null,
    curtidas: 9340,
    comentarios_count: 234,
    views: 41200,
    liked: false,
    created_at: hoursAgo(24),
    usuario: toPreview(users[7]),
  },
  {
    id: 7,
    usuario_id: 7,
    tipo: "texto",
    conteudo: "Слава Богу! Навіть у важкі часи, ми разом у Христі. Дякую всім братам і сестрам з Бразилії, які молились за Україну. Бог вас благословить! 🇺🇦🙏",
    media_url: null,
    curtidas: 23400,
    comentarios_count: 892,
    views: 89000,
    liked: false,
    created_at: daysAgo(1),
    usuario: toPreview(users[6]),
  },
  {
    id: 8,
    usuario_id: 11,
    tipo: "imagem",
    conteudo: "Gratidão infinita! Hoje completei 1 ano nesta plataforma. Já fiz amigos em 8 países diferentes! Deus é bom o tempo todo! 🌍❤️👑",
    media_url: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600",
    curtidas: 4560,
    comentarios_count: 123,
    views: 18900,
    liked: true,
    created_at: daysAgo(1),
    usuario: toPreview(users[10]),
  },
  {
    id: 9,
    usuario_id: 6,
    tipo: "texto",
    conteudo: "¡Alabado sea Dios! Conectando con hermanos de Brasil, Israel, India y China en una sola plataforma. El amor de Cristo une el mundo entero. ¡Aleluya! 🙌🇪🇸",
    media_url: null,
    curtidas: 7890,
    comentarios_count: 234,
    views: 34500,
    liked: false,
    created_at: daysAgo(2),
    usuario: toPreview(users[5]),
  },
  {
    id: 10,
    usuario_id: 13,
    tipo: "imagem",
    conteudo: "Lode al Signore! Questa piattaforma è un miracolo moderno. Italiani, brasiliani, israeliani — tutti uniti nel nome di Gesù! 🇮🇹✝️",
    media_url: "https://images.unsplash.com/photo-1541614101331-1a5a3a194e92?w=600",
    curtidas: 3210,
    comentarios_count: 87,
    views: 12300,
    liked: false,
    created_at: daysAgo(2),
    usuario: toPreview(users[12]),
  },
  {
    id: 11,
    usuario_id: 10,
    tipo: "texto",
    conteudo: "哈利路亚！感谢主让我找到这个平台，可以和来自巴西、以色列、印度的弟兄姐妹们连接。耶稣爱你们！🙏🇨🇳",
    media_url: null,
    curtidas: 5670,
    comentarios_count: 145,
    views: 23400,
    liked: false,
    created_at: daysAgo(3),
    usuario: toPreview(users[9]),
  },
  {
    id: 12,
    usuario_id: 3,
    tipo: "live",
    conteudo: "🔴 AO VIVO AGORA — Culto Internacional de Oração! Junte-se a nós de qualquer país! Estamos orando por avivamento mundial. Entre agora!",
    media_url: null,
    curtidas: 18900,
    comentarios_count: 2340,
    views: 156000,
    liked: false,
    created_at: minutesAgo(30),
    usuario: toPreview(users[2]),
  },
];

// ============================================================
// COMMENTS
// ============================================================
export const comments: Comment[] = [
  { id: 1, post_id: 1, usuario_id: 3, conteudo: "Amém! Gloria a Deus! Oramos por vocês também! 🙏🇧🇷", curtidas: 234, presente_emoji: null, created_at: hoursAgo(1), usuario: toPreview(users[2]) },
  { id: 2, post_id: 1, usuario_id: 4, conteudo: "Amen! God bless Jerusalem! Praying for you from USA 🇺🇸❤️", curtidas: 189, presente_emoji: "🙏", created_at: hoursAgo(2), usuario: toPreview(users[3]) },
  { id: 3, post_id: 1, usuario_id: 8, conteudo: "Hallelujah from India! 🇮🇳 Jesus is Lord!", curtidas: 145, presente_emoji: null, created_at: hoursAgo(1), usuario: toPreview(users[7]) },
  { id: 4, post_id: 2, usuario_id: 4, conteudo: "Amen Pastor Marcos! This platform is a blessing! God is connecting the world!", curtidas: 89, presente_emoji: "👑", created_at: hoursAgo(4), usuario: toPreview(users[3]) },
  { id: 5, post_id: 2, usuario_id: 6, conteudo: "¡Amén hermano! ¡Dios nos une a todos! 🙌🇪🇸", curtidas: 67, presente_emoji: null, created_at: hoursAgo(5), usuario: toPreview(users[5]) },
  { id: 6, post_id: 3, usuario_id: 3, conteudo: "Amém irmã Sarah! É exatamente isso! O céu vai ser assim! 🌍❤️", curtidas: 234, presente_emoji: "❤️", created_at: hoursAgo(7), usuario: toPreview(users[2]) },
  { id: 7, post_id: 5, usuario_id: 3, conteudo: "Glória a Deus! Que avivamento! Estamos orando pelo mundo todo! 🔥🙏", curtidas: 892, presente_emoji: "📖", created_at: hoursAgo(17), usuario: toPreview(users[2]) },
  { id: 8, post_id: 5, usuario_id: 4, conteudo: "AMEN! The Holy Spirit is moving! USA is praying for the world! 🇺🇸🔥", curtidas: 567, presente_emoji: null, created_at: hoursAgo(18), usuario: toPreview(users[3]) },
  { id: 9, post_id: 12, usuario_id: 4, conteudo: "Joining from New York! God is moving! 🇺🇸🔥", curtidas: 123, presente_emoji: "🕊️", created_at: minutesAgo(20), usuario: toPreview(users[3]) },
  { id: 10, post_id: 12, usuario_id: 7, conteudo: "Приєднуємося з України! Слава Богу! 🇺🇦🙏", curtidas: 89, presente_emoji: null, created_at: minutesAgo(15), usuario: toPreview(users[6]) },
];

// ============================================================
// REELS
// ============================================================
export const reels: Reel[] = [
  {
    id: 1,
    titulo: "Louvor Internacional - Unidos em Cristo",
    embed_url: "https://www.youtube.com/embed/3G-y1GfMSA0",
    plataforma: "youtube",
    thumbnail_url: "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=400",
    curtidas: 45200,
    views: 234000,
    liked: false,
    created_at: hoursAgo(6),
    usuario: toPreview(users[8]),
  },
  {
    id: 2,
    titulo: "Adoração ao Vivo - Igreja de Jerusalém",
    embed_url: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    plataforma: "youtube",
    thumbnail_url: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400",
    curtidas: 32100,
    views: 178000,
    liked: true,
    created_at: hoursAgo(12),
    usuario: toPreview(users[1]),
  },
  {
    id: 3,
    titulo: "Pregação Poderosa - Pastor Marcos",
    embed_url: "https://www.youtube.com/embed/kJQP7kiw5Fk",
    plataforma: "youtube",
    thumbnail_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
    curtidas: 28900,
    views: 145000,
    liked: false,
    created_at: daysAgo(1),
    usuario: toPreview(users[2]),
  },
  {
    id: 4,
    titulo: "Worship Night - Sarah Johnson",
    embed_url: "https://www.youtube.com/embed/OPf0YbXqDm0",
    plataforma: "youtube",
    thumbnail_url: "https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=400",
    curtidas: 19400,
    views: 89000,
    liked: false,
    created_at: daysAgo(2),
    usuario: toPreview(users[3]),
  },
  {
    id: 5,
    titulo: "Testemunho - Milagre de Cura na Índia",
    embed_url: "https://www.youtube.com/embed/IcrbM1l_BoI",
    plataforma: "youtube",
    thumbnail_url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400",
    curtidas: 56700,
    views: 312000,
    liked: false,
    created_at: daysAgo(3),
    usuario: toPreview(users[7]),
  },
  {
    id: 6,
    titulo: "הלל ושירה - מירושלים לעולם",
    embed_url: "https://www.youtube.com/embed/yAQKunpQ8Tg",
    plataforma: "youtube",
    thumbnail_url: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=400",
    curtidas: 12300,
    views: 67000,
    liked: false,
    created_at: daysAgo(4),
    usuario: toPreview(users[4]),
  },
  {
    id: 7,
    titulo: "Момент поклоніння з України 🇺🇦",
    embed_url: "https://www.youtube.com/embed/Hy-UgMCnHKI",
    plataforma: "youtube",
    thumbnail_url: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400",
    curtidas: 34500,
    views: 189000,
    liked: false,
    created_at: daysAgo(5),
    usuario: toPreview(users[6]),
  },
  {
    id: 8,
    titulo: "赞美诗歌 - 中国教会 🇨🇳",
    embed_url: "https://www.youtube.com/embed/6QIGU9mEQU8",
    plataforma: "youtube",
    thumbnail_url: "https://images.unsplash.com/photo-1511735111819-9a3f7709049c?w=400",
    curtidas: 8900,
    views: 45000,
    liked: false,
    created_at: daysAgo(6),
    usuario: toPreview(users[9]),
  },
];

// ============================================================
// MARKETPLACE
// ============================================================
export const marketplaceItems: MarketplaceItem[] = [
  { id: 1, titulo: "Bíblia de Estudo NVI - Capa Luxo", descricao: "Bíblia de estudo completa com comentários, mapas e concordância. Capa em couro legítimo dourado.", preco: 89.90, categoria: "Bíblias", foto_url: "https://images.unsplash.com/photo-1474117600994-9c64f8dfd1f0?w=400", condicao: "novo", created_at: daysAgo(5), usuario: toPreview(users[10]) },
  { id: 2, titulo: "Violão de Louvor - Yamaha F310", descricao: "Violão para ministério de louvor. Excelente estado, perfeito para adoração. Inclui capa.", preco: 750.00, categoria: "Instrumentos", foto_url: "https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=400", condicao: "usado", created_at: daysAgo(3), usuario: toPreview(users[2]) },
  { id: 3, titulo: "Livro - Teologia Sistemática Grudem", descricao: "Livro teologia sistemática de Wayne Grudem, edição revisada. Indispensável para pastores e líderes.", preco: 120.00, categoria: "Literatura", foto_url: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400", condicao: "novo", created_at: daysAgo(2), usuario: toPreview(users[5]) },
  { id: 4, titulo: "Vestido de Moda Modesta - M/G", descricao: "Vestido floral elegante para culto, formaturas e eventos religiosos. Saia longa midi. Cor: azul marinho.", preco: 145.00, categoria: "Moda Modesta", foto_url: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400", condicao: "novo", created_at: daysAgo(1), usuario: toPreview(users[10]) },
  { id: 5, titulo: "Serviço de Levita - Ministério de Louvor", descricao: "Músico profissional disponível para cultos, casamentos e eventos cristãos. 15 anos de experiência.", preco: 350.00, categoria: "Serviços", foto_url: "https://images.unsplash.com/photo-1568702846914-96b305d2aaeb?w=400", condicao: "serviço", created_at: daysAgo(4), usuario: toPreview(users[2]) },
  { id: 6, titulo: "Teclado Casio CT-S300 para Igreja", descricao: "Teclado perfeito para igrejas menores e missões. 61 teclas, 48 timbres. Em ótimo estado.", preco: 550.00, categoria: "Instrumentos", foto_url: "https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?w=400", condicao: "usado", created_at: daysAgo(6), usuario: toPreview(users[8]) },
  { id: 7, titulo: "Coleção Devocional Spurgeon - 3 volumes", descricao: "Clássicos de Charles Spurgeon. Morning and Evening + The Treasury of David. Importados.", preco: 220.00, categoria: "Literatura", foto_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400", condicao: "novo", created_at: daysAgo(7), usuario: toPreview(users[12]) },
  { id: 8, titulo: "Camisa Social Cristã - Evangelismo", descricao: "Camisa social masculina com versículo bordado. Perfeita para pregadores e evangelistas. G/GG.", preco: 89.00, categoria: "Moda Modesta", foto_url: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400", condicao: "novo", created_at: daysAgo(8), usuario: toPreview(users[5]) },
  { id: 9, titulo: "Santa Ceia - Kit Completo para Igreja", descricao: "Kit completo para celebração da Santa Ceia. 100 cálices descartáveis + suco de uva + pão ázimo.", preco: 45.00, categoria: "Ministério", foto_url: "https://images.unsplash.com/photo-1470309864661-68328b2cd0a5?w=400", condicao: "novo", created_at: daysAgo(9), usuario: toPreview(users[8]) },
  { id: 10, titulo: "Microfone Sem Fio - Culto e Pregação", descricao: "Microfone sem fio profissional Shure para cultos e conferências. Alcance 50m. Inclui transmissor.", preco: 890.00, categoria: "Instrumentos", foto_url: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?w=400", condicao: "usado", created_at: daysAgo(10), usuario: toPreview(users[1]) },
];

// ============================================================
// UNIVERSAL CHAT MESSAGES
// ============================================================
export const universalMessages: ChatMessage[] = [
  { id: 1, conteudo: "Glória a Deus! 🙌 Orando por todos vocês!", conteudo_original: "Glória a Deus! 🙌 Orando por todos vocês!", idioma_original: "pt-BR", prioridade: false, presente_emoji: null, created_at: minutesAgo(45), usuario: toPreview(users[2]) },
  { id: 2, conteudo: "God bless you all from New York! 🇺🇸 Praying for the world!", conteudo_original: "God bless you all from New York! 🇺🇸 Praying for the world!", idioma_original: "en", prioridade: true, presente_emoji: "👑", created_at: minutesAgo(40), usuario: toPreview(users[3]) },
  { id: 3, conteudo: "ברוך השם! שלום מישראל לכל העולם! 🇮🇱", conteudo_original: "ברוך השם! שלום מישראל לכל העולם! 🇮🇱", idioma_original: "he", prioridade: false, presente_emoji: null, created_at: minutesAgo(35), usuario: toPreview(users[4]) },
  { id: 4, conteudo: "Amém! Enviando orações da Ucrânia para o mundo todo! 🇺🇦🙏", conteudo_original: "Амінь! Надсилаємо молитви з України до всього світу!", idioma_original: "uk", prioridade: false, presente_emoji: null, created_at: minutesAgo(30), usuario: toPreview(users[6]) },
  { id: 5, conteudo: "Hallelujah from India! Praying for healing worldwide! 🇮🇳✨", conteudo_original: "Hallelujah from India! Praying for healing worldwide! 🇮🇳✨", idioma_original: "hi", prioridade: true, presente_emoji: "🙏", created_at: minutesAgo(25), usuario: toPreview(users[7]) },
  { id: 6, conteudo: "哈利路亚！爱你们！从中国问候！🇨🇳", conteudo_original: "哈利路亚！爱你们！从中国问候！🇨🇳", idioma_original: "zh", prioridade: false, presente_emoji: null, created_at: minutesAgo(20), usuario: toPreview(users[9]) },
  { id: 7, conteudo: "¡Aleluya! ¡Dios les bendiga a todos desde España! 🇪🇸❤️", conteudo_original: "¡Aleluya! ¡Dios les bendiga a todos desde España! 🇪🇸❤️", idioma_original: "es", prioridade: false, presente_emoji: null, created_at: minutesAgo(15), usuario: toPreview(users[5]) },
  { id: 8, conteudo: "Lode al Signore! Preghiamo insieme per la pace nel mondo! 🇮🇹✝️", conteudo_original: "Lode al Signore! Preghiamo insieme per la pace nel mondo! 🇮🇹✝️", idioma_original: "it", prioridade: true, presente_emoji: "🕊️", created_at: minutesAgo(10), usuario: toPreview(users[12]) },
  { id: 9, conteudo: "Amen! Tanrı hepinizi kutsasın Türkiye'den! 🇹🇷🙏", conteudo_original: "Amen! Tanrı hepinizi kutsasın Türkiye'den! 🇹🇷🙏", idioma_original: "tr", prioridade: false, presente_emoji: null, created_at: minutesAgo(8), usuario: toPreview(users[11]) },
  { id: 10, conteudo: "Que bênção imensa essa plataforma! Amigos de 11 países em 1 chat! Maravilhoso! 🌍", conteudo_original: "Que bênção imensa essa plataforma! Amigos de 11 países em 1 chat! Maravilhoso! 🌍", idioma_original: "pt-BR", prioridade: false, presente_emoji: null, created_at: minutesAgo(5), usuario: toPreview(users[10]) },
  { id: 11, conteudo: "Orando por avivamento global! O Espírito Santo vai se mover sobre as nações! 🔥", conteudo_original: "Orando por avivamento global! O Espírito Santo vai se mover sobre as nações! 🔥", idioma_original: "pt-BR", prioridade: false, presente_emoji: null, created_at: minutesAgo(2), usuario: toPreview(users[2]) },
  { id: 12, conteudo: "Jesus loves the whole world! United in prayer! 🌍❤️✝️", conteudo_original: "Jesus loves the whole world! United in prayer! 🌍❤️✝️", idioma_original: "en", prioridade: false, presente_emoji: null, created_at: minutesAgo(1), usuario: toPreview(users[3]) },
];

// ============================================================
// PRIVATE MESSAGES (user 3 <-> user 2)
// ============================================================
export const privateMessages: Record<string, ChatMessage[]> = {
  "3-2": [
    { id: 1, conteudo: "Shalom Pastor Marcos! Oramos por vocês no Brasil! 🇮🇱🙏", conteudo_original: "שלום פסטור מרקוס! אנחנו מתפללים עליכם בברזיל! 🇮🇱🙏", idioma_original: "he", prioridade: false, presente_emoji: null, created_at: hoursAgo(3), usuario: toPreview(users[1]) },
    { id: 2, conteudo: "Shalom Pastor! Que alegria! Oramos por Israel todo dia! Amém! 🙏🇧🇷", conteudo_original: "Shalom Pastor! Que alegria! Oramos por Israel todo dia! Amém! 🙏🇧🇷", idioma_original: "pt-BR", prioridade: false, presente_emoji: null, created_at: hoursAgo(3), usuario: toPreview(users[2]) },
    { id: 3, conteudo: "Podemos fazer uma live juntos? Brasil e Israel unindo forças para Cristo! 🌍", conteudo_original: "האם נוכל לעשות לייב ביחד? ברזיל וישראל מאחדים כוחות למען ישוע! 🌍", idioma_original: "he", prioridade: false, presente_emoji: null, created_at: hoursAgo(2), usuario: toPreview(users[1]) },
    { id: 4, conteudo: "Sim! Que ideia incrível! Vamos combinar os detalhes. Que dia seria bom para você? 📅", conteudo_original: "Sim! Que ideia incrível! Vamos combinar os detalhes. Que dia seria bom para você? 📅", idioma_original: "pt-BR", prioridade: false, presente_emoji: null, created_at: hoursAgo(1), usuario: toPreview(users[2]) },
  ],
};

// ============================================================
// GIFTS
// ============================================================
export const gifts: Gift[] = [
  { id: 1, tipo: "coroa", valor_moedas: 500, valor_real: 25.00, taxa_admin: 7.50, valor_liquido: 17.50, contexto: "live", created_at: hoursAgo(2), remetente: toPreview(users[3]), destinatario: toPreview(users[1]) },
  { id: 2, tipo: "pomba", valor_moedas: 200, valor_real: 10.00, taxa_admin: 3.00, valor_liquido: 7.00, contexto: "perfil", created_at: hoursAgo(5), remetente: toPreview(users[2]), destinatario: toPreview(users[7]) },
  { id: 3, tipo: "biblia", valor_moedas: 1000, valor_real: 50.00, taxa_admin: 15.00, valor_liquido: 35.00, contexto: "comentario", created_at: daysAgo(1), remetente: toPreview(users[8]), destinatario: toPreview(users[2]) },
  { id: 4, tipo: "coracao", valor_moedas: 100, valor_real: 5.00, taxa_admin: 1.50, valor_liquido: 3.50, contexto: "perfil", created_at: daysAgo(2), remetente: toPreview(users[6]), destinatario: toPreview(users[4]) },
  { id: 5, tipo: "maos", valor_moedas: 300, valor_real: 15.00, taxa_admin: 4.50, valor_liquido: 10.50, contexto: "live", created_at: daysAgo(3), remetente: toPreview(users[5]), destinatario: toPreview(users[8]) },
];

// ============================================================
// WITHDRAWALS
// ============================================================
export const withdrawals: Withdrawal[] = [
  { id: 1, valor: 500.00, chave_pix: "ibj@jerusalem.com", status: "pendente", automatico: false, created_at: hoursAgo(4), usuario: toPreview(users[1]) },
  { id: 2, valor: 2500.00, chave_pix: "img@graca.com", status: "pendente", automatico: true, created_at: hoursAgo(8), usuario: toPreview(users[8]) },
  { id: 3, valor: 120.00, chave_pix: "marcos@email.com", status: "aprovado", automatico: false, created_at: daysAgo(1), usuario: toPreview(users[2]) },
  { id: 4, valor: 85.00, chave_pix: "priya@india.com", status: "aprovado", automatico: false, created_at: daysAgo(2), usuario: toPreview(users[7]) },
  { id: 5, valor: 340.00, chave_pix: "antonio@spain.com", status: "pendente", automatico: false, created_at: hoursAgo(12), usuario: toPreview(users[5]) },
];

// ============================================================
// BLACKLIST
// ============================================================
export const blacklist: BlacklistEntry[] = [
  { id: 1, cpf: "123.456.789-00", email: "golpista1@fake.com", telefone: "+55 11 99999-9999", motivo: "Aplicou golpe financeiro via Pix. Tentativa de fraude em 12 transações.", created_at: daysAgo(15) },
  { id: 2, cpf: null, email: "spam@spam.com", telefone: null, motivo: "Spam massivo de pedidos de doação fora da plataforma. 50+ posts removidos.", created_at: daysAgo(8) },
  { id: 3, cpf: "987.654.321-00", email: "fraude@fake.com", telefone: "+55 21 88888-8888", motivo: "Cartão de crédito clonado. Múltiplas transações rejeitadas em 6 horas.", created_at: daysAgo(3) },
];

// ============================================================
// NOTIFICATIONS
// ============================================================
export const notifications: Notification[] = [
  { id: 1, titulo: "Pastor Marcos curtiu sua publicação", mensagem: "Pastor Marcos curtiu seu post sobre avivamento mundial.", lida: false, tipo: "curtida", created_at: minutesAgo(30) },
  { id: 2, titulo: "Nova solicitação de amizade", mensagem: "Sarah Johnson enviou uma solicitação de amizade.", lida: false, tipo: "amizade", created_at: hoursAgo(2) },
  { id: 3, titulo: "Você recebeu um presente! 👑", mensagem: "Rev. Priya Sharma enviou uma Coroa da Vitória para você!", lida: true, tipo: "presente", created_at: hoursAgo(5) },
  { id: 4, titulo: "Igreja Batista de Jerusalém está ao vivo!", mensagem: "Igreja Batista de Jerusalém iniciou uma live. Junte-se agora!", lida: true, tipo: "live", created_at: hoursAgo(8) },
  { id: 5, titulo: "🎺 Mensagem do Administrador", mensagem: "Bem-vindos à maior rede cristã global! Compartilhe com seus amigos e igrejas!", lida: true, tipo: "harpa", created_at: daysAgo(1) },
];

// ============================================================
// ENGAGEMENT CONFIG
// ============================================================
export let engagementConfig: EngagementConfig = {
  id: 1,
  views_multiplier: 5,
  curtidas_multiplier: 3,
  comentarios_ativos: true,
  updated_at: daysAgo(1),
};

// ============================================================
// BANNER
// ============================================================
export let banner: Banner = {
  id: 1,
  titulo: "CONECTANDO O MUNDO COM JESUS",
  subtitulo: "Conectando igrejas, pessoas e culturas diferentes do mundo todo. Junte-se a mais de 2 milhões de cristãos em 142 países.",
  imagem_url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200",
  cta_texto: "Cadastrar-se Grátis",
};

// ============================================================
// COUNTERS
// ============================================================
export let nextUserId = users.length + 1;
export let nextPostId = posts.length + 1;
export let nextCommentId = comments.length + 1;
export let nextReelId = reels.length + 1;
export let nextMarketplaceId = marketplaceItems.length + 1;
export let nextMessageId = universalMessages.length + 1;
export let nextGiftId = gifts.length + 1;
export let nextWithdrawalId = withdrawals.length + 1;
export let nextNotificationId = notifications.length + 1;

export function incUserId() { return nextUserId++; }
export function incPostId() { return nextPostId++; }
export function incCommentId() { return nextCommentId++; }
export function incReelId() { return nextReelId++; }
export function incMarketplaceId() { return nextMarketplaceId++; }
export function incMessageId() { return nextMessageId++; }
export function incGiftId() { return nextGiftId++; }
export function incWithdrawalId() { return nextWithdrawalId++; }
export function incNotificationId() { return nextNotificationId++; }

export { toPreview };
