# Conectando o Mundo com Jesus

## Credenciais
- admin@cmj.com | admin123
- ibj@jerusalem.com | senha123

## Rodar
pnpm install
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/cmj-app run dev
